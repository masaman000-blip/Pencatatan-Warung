import React, { useState, useMemo } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Transaction, PRESET_VENDORS } from '../types';
import { formatRupiah, formatTanggalIndo, exportToCSV } from '../utils/formatters';
import {
  Calendar,
  CalendarDays,
  CalendarRange,
  Download,
  Printer,
  TrendingUp,
  TrendingDown,
  Store,
  ArrowDownRight,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  ArrowLeft,
} from 'lucide-react';
import { BatikBorderAccent } from './Ornaments';

interface DetailedRecapPageProps {
  transactions: Transaction[];
  warungName: string;
  onExit?: () => void;
}

export const DetailedRecapPage: React.FC<DetailedRecapPageProps> = ({
  transactions,
  warungName,
  onExit,
}) => {
  const [recapMode, setRecapMode] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  // Daily State
  const [selectedDay, setSelectedDay] = useState<string>('2026-09-24');

  // Weekly State (Anchor date)
  const [weeklyAnchor, setWeeklyAnchor] = useState<string>('2026-09-24');

  // Monthly State
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-09');

  // ==========================================
  // 1. DATA REKAP 1 HARI (HARIAN)
  // ==========================================
  const dailyTransactions = useMemo(() => {
    return transactions.filter((t) => t.date === selectedDay);
  }, [transactions, selectedDay]);

  const dailyIncome = dailyTransactions
    .filter((t) => t.type === 'pemasukan')
    .reduce((sum, t) => sum + t.amount, 0);

  const dailyExpense = dailyTransactions
    .filter((t) => t.type === 'pengeluaran')
    .reduce((sum, t) => sum + t.amount, 0);

  const dailyNet = dailyIncome - dailyExpense;

  const dailyExpensesOnly = dailyTransactions.filter((t) => t.type === 'pengeluaran');

  // Breakdown per toko for daily
  const dailyVendorBreakdown = useMemo(() => {
    return PRESET_VENDORS.map((vendor) => {
      const match = dailyExpensesOnly.filter((t) => t.category === vendor);
      const amount = match.reduce((sum, t) => sum + t.amount, 0);
      const percentage = dailyExpense > 0 ? Math.round((amount / dailyExpense) * 100) : 0;
      return { vendor, amount, count: match.length, percentage };
    });
  }, [dailyExpensesOnly, dailyExpense]);

  // ==========================================
  // 2. DATA REKAP 1 MINGGU (7 HARI TERAKHIR)
  // ==========================================
  const weeklyDateRange = useMemo(() => {
    const end = new Date(`${weeklyAnchor}T23:59:59`);
    const start = new Date(end.getTime() - 6 * 24 * 60 * 60 * 1000); // 7 days inclusive
    const startStr = start.toISOString().split('T')[0];
    const endStr = end.toISOString().split('T')[0];
    return { start, end, startStr, endStr };
  }, [weeklyAnchor]);

  const weeklyTransactions = useMemo(() => {
    return transactions.filter((t) => {
      return t.date >= weeklyDateRange.startStr && t.date <= weeklyDateRange.endStr;
    });
  }, [transactions, weeklyDateRange]);

  const weeklyIncome = weeklyTransactions
    .filter((t) => t.type === 'pemasukan')
    .reduce((sum, t) => sum + t.amount, 0);

  const weeklyExpense = weeklyTransactions
    .filter((t) => t.type === 'pengeluaran')
    .reduce((sum, t) => sum + t.amount, 0);

  const weeklyNet = weeklyIncome - weeklyExpense;
  const weeklyExpensesOnly = weeklyTransactions.filter((t) => t.type === 'pengeluaran');

  // 7 days breakdown (day by day)
  const daysOfWeekBreakdown = useMemo(() => {
    const days: { dateStr: string; label: string; income: number; expense: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(weeklyDateRange.end.getTime() - i * 24 * 60 * 60 * 1000);
      const dStr = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'numeric' });
      const txDay = transactions.filter((t) => t.date === dStr);
      const inc = txDay.filter((t) => t.type === 'pemasukan').reduce((s, t) => s + t.amount, 0);
      const exp = txDay.filter((t) => t.type === 'pengeluaran').reduce((s, t) => s + t.amount, 0);
      days.push({ dateStr: dStr, label: dayName, income: inc, expense: exp });
    }
    return days;
  }, [transactions, weeklyDateRange]);

  // Vendor breakdown for week
  const weeklyVendorBreakdown = useMemo(() => {
    return PRESET_VENDORS.map((vendor) => {
      const match = weeklyExpensesOnly.filter((t) => t.category === vendor);
      const amount = match.reduce((sum, t) => sum + t.amount, 0);
      const percentage = weeklyExpense > 0 ? Math.round((amount / weeklyExpense) * 100) : 0;
      return { vendor, amount, count: match.length, percentage };
    });
  }, [weeklyExpensesOnly, weeklyExpense]);

  // ==========================================
  // 3. DATA REKAP 1 BULAN (BULANAN)
  // ==========================================
  const monthlyTransactions = useMemo(() => {
    return transactions.filter((t) => t.date.startsWith(selectedMonth));
  }, [transactions, selectedMonth]);

  const monthlyIncome = monthlyTransactions
    .filter((t) => t.type === 'pemasukan')
    .reduce((sum, t) => sum + t.amount, 0);

  const monthlyExpense = monthlyTransactions
    .filter((t) => t.type === 'pengeluaran')
    .reduce((sum, t) => sum + t.amount, 0);

  const monthlyNet = monthlyIncome - monthlyExpense;
  const monthlyExpensesOnly = monthlyTransactions.filter((t) => t.type === 'pengeluaran');

  // Breakdown by 4 weeks of the month
  const monthlyWeeksBreakdown = useMemo(() => {
    const weeks = [
      { label: 'Minggu 1 (Tgl 1 - 7)', start: `${selectedMonth}-01`, end: `${selectedMonth}-07` },
      { label: 'Minggu 2 (Tgl 8 - 14)', start: `${selectedMonth}-08`, end: `${selectedMonth}-14` },
      { label: 'Minggu 3 (Tgl 15 - 21)', start: `${selectedMonth}-15`, end: `${selectedMonth}-21` },
      { label: 'Minggu 4 (Tgl 22 - Akhir)', start: `${selectedMonth}-22`, end: `${selectedMonth}-31` },
    ];
    return weeks.map((w) => {
      const txs = monthlyTransactions.filter((t) => t.date >= w.start && t.date <= w.end);
      const inc = txs.filter((t) => t.type === 'pemasukan').reduce((s, t) => s + t.amount, 0);
      const exp = txs.filter((t) => t.type === 'pengeluaran').reduce((s, t) => s + t.amount, 0);
      return { ...w, income: inc, expense: exp, net: inc - exp, count: txs.length };
    });
  }, [monthlyTransactions, selectedMonth]);

  // Vendor breakdown for month
  const monthlyVendorBreakdown = useMemo(() => {
    return PRESET_VENDORS.map((vendor) => {
      const match = monthlyExpensesOnly.filter((t) => t.category === vendor);
      const amount = match.reduce((sum, t) => sum + t.amount, 0);
      const percentage = monthlyExpense > 0 ? Math.round((amount / monthlyExpense) * 100) : 0;
      return { vendor, amount, count: match.length, percentage };
    });
  }, [monthlyExpensesOnly, monthlyExpense]);

  return (
    <div className="space-y-5">
      {/* Top Header & Mode Navigation Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200/80 shadow-xs space-y-4">
        {onExit && (
          <div className="pb-3 border-b border-stone-100 flex items-center justify-between">
            <button
              type="button"
              onClick={onExit}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 hover:text-stone-900 text-xs font-semibold cursor-pointer transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Keluar ke Ringkasan Utama</span>
            </button>
          </div>
        )}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                Laporan Akuntansi Warung
              </span>
              <span className="text-stone-300">·</span>
              <span className="text-xs text-stone-500">{warungName}</span>
            </div>
            <h2 className="text-lg font-bold text-stone-900 mt-0.5">
              Rekapitulasi Keuangan Terpadu
            </h2>
            <p className="text-xs text-stone-500">
              Pilih periode rekapan: 1 Hari, 1 Minggu, atau 1 Bulan penuh untuk analisis arus kas yang teliti dan rapi.
            </p>
          </div>

          {/* 3 Main Mode Buttons */}
          <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl shrink-0 self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setRecapMode('daily')}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                recapMode === 'daily'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Calendar className="w-4 h-4 text-emerald-700" />
              <span>Rekap 1 Hari</span>
            </button>

            <button
              type="button"
              onClick={() => setRecapMode('weekly')}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                recapMode === 'weekly'
                  ? 'bg-white text-amber-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <CalendarDays className="w-4 h-4 text-amber-700" />
              <span>Rekap 1 Minggu</span>
            </button>

            <button
              type="button"
              onClick={() => setRecapMode('monthly')}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                recapMode === 'monthly'
                  ? 'bg-white text-blue-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <CalendarRange className="w-4 h-4 text-blue-700" />
              <span>Rekap 1 Bulan</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mode Sub-page Content with Silky Smooth Animation */}
      <AnimatePresence mode="wait">
        <motion.div
          key={recapMode}
          initial={{ opacity: 0, y: 10, filter: 'blur(2px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -8, filter: 'blur(1px)' }}
          transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
        >
          {/* ======================================================== */}
          {/* MODE 1: REKAP 1 HARI (HARIAN)                            */}
          {/* ======================================================== */}
          {recapMode === 'daily' && (
            <div className="space-y-4">
              {/* Controls Bar for Daily */}
          <div className="bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="text-xs font-semibold text-stone-700">Pilih Tanggal Rekap Harian:</span>
              <input
                type="date"
                min="2026-01-01"
                value={selectedDay}
                onChange={(e) => setSelectedDay(e.target.value)}
                className="px-2.5 py-1 bg-stone-50 border border-stone-200 rounded-lg text-xs font-bold text-stone-800"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => exportToCSV(dailyTransactions, `Rekap-Harian-${selectedDay}.csv`)}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh CSV Harian</span>
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak</span>
              </button>
            </div>
          </div>

          {/* 3 Metric Cards Harian */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Kas Masuk Hari Ini
                </span>
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center">
                  <ArrowDownRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-emerald-800 tabular-nums">
                {formatRupiah(dailyIncome)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
                Penjualan Harian Warung
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Kas Keluar (Belanja)
                </span>
                <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-rose-800 tabular-nums">
                {formatRupiah(dailyExpense)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
                {dailyExpensesOnly.length} Kali Belanja Grosir
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Saldo Bersih Hari Ini
                </span>
                <div className={`w-7 h-7 rounded-lg border flex items-center justify-center ${
                  dailyNet >= 0 ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-700'
                }`}>
                  {dailyNet >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                </div>
              </div>
              <div className={`mt-2 text-2xl font-bold tabular-nums ${dailyNet >= 0 ? 'text-emerald-800' : 'text-rose-700'}`}>
                {formatRupiah(dailyNet)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2 flex justify-between">
                <span>{dailyNet >= 0 ? 'Surplus Kas' : 'Defisit Kas'}</span>
                <span className="font-mono text-stone-400">{selectedDay}</span>
              </div>
            </div>
          </div>

          {/* Rincian Belanja per Toko Hari Ini */}
          <div className="bg-white p-5 rounded-xl border border-stone-200/80 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
              <Store className="w-4 h-4 text-emerald-800" />
              <span>Rincian Belanja per Toko / Grosir Hari Ini ({formatTanggalIndo(selectedDay)})</span>
            </h3>

            {dailyExpense === 0 ? (
              <p className="text-xs text-stone-500 italic py-2">
                Tidak ada catatan belanja grosir pada tanggal ini.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {dailyVendorBreakdown.map((item) => (
                  <div key={item.vendor} className="p-3 bg-stone-50 rounded-lg border border-stone-200/70 space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold text-stone-800">
                      <span>{item.vendor}</span>
                      <span className="font-mono text-rose-700">{formatRupiah(item.amount)}</span>
                    </div>
                    <div className="w-full bg-stone-200 rounded-full h-1.5 overflow-hidden">
                      <div className="bg-amber-500 h-1.5 rounded-full" style={{ width: `${item.percentage}%` }} />
                    </div>
                    <div className="text-[10px] text-stone-500 flex justify-between pt-0.5">
                      <span>{item.count} Transaksi</span>
                      <span>{item.percentage}% dari total belanja</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tabel Transaksi Hari Ini */}
          <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-stone-50/70 border-b border-stone-100 flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                Daftar Transaksi Tanggal {formatTanggalIndo(selectedDay)}
              </span>
              <span className="text-xs font-mono text-stone-500">
                {dailyTransactions.length} Transaksi
              </span>
            </div>

            {dailyTransactions.length === 0 ? (
              <div className="p-8 text-center text-xs text-stone-500">
                Belum ada transaksi yang dicatat pada tanggal ini.
              </div>
            ) : (
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50/50 border-b border-stone-100 text-stone-500 uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-4">Jam</th>
                    <th className="py-2.5 px-4">Jenis</th>
                    <th className="py-2.5 px-4">Deskripsi</th>
                    <th className="py-2.5 px-4 text-right">Nominal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {dailyTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-stone-50/50">
                      <td className="py-2.5 px-4 font-mono text-stone-500">{tx.time || '-'}</td>
                      <td className="py-2.5 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          tx.type === 'pemasukan' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                        }`}>
                          {tx.type === 'pemasukan' ? 'Kas Masuk' : 'Kas Keluar'}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 font-medium text-stone-800">
                        {tx.type === 'pengeluaran' ? `Belanja di ${tx.category}` : 'Penjualan Harian Warung'}
                      </td>
                      <td className={`py-2.5 px-4 text-right font-bold font-mono tabular-nums ${
                        tx.type === 'pemasukan' ? 'text-emerald-700' : 'text-rose-700'
                      }`}>
                        {tx.type === 'pemasukan' ? '+' : '-'} {formatRupiah(tx.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODE 2: REKAP 1 MINGGU (7 HARI)                         */}
      {/* ======================================================== */}
      {recapMode === 'weekly' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Controls Bar for Weekly */}
          <div className="bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-amber-700 shrink-0" />
              <span className="text-xs font-semibold text-stone-700">Tanggal Akhir 7 Hari:</span>
              <input
                type="date"
                min="2026-01-07"
                value={weeklyAnchor}
                onChange={(e) => setWeeklyAnchor(e.target.value)}
                className="px-2.5 py-1 bg-stone-50 border border-stone-200 rounded-lg text-xs font-bold text-stone-800"
              />
              <span className="text-xs text-stone-500 font-medium hidden sm:inline">
                ({weeklyDateRange.startStr} s/d {weeklyDateRange.endStr})
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => exportToCSV(weeklyTransactions, `Rekap-Mingguan-${weeklyDateRange.startStr}-${weeklyDateRange.endStr}.csv`)}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh CSV 1 Minggu</span>
              </button>
            </div>
          </div>

          {/* 3 Metric Cards Mingguan */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Total Kas Masuk (7 Hari)
                </span>
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center">
                  <ArrowDownRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-emerald-800 tabular-nums">
                {formatRupiah(weeklyIncome)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
                Rata-rata: {formatRupiah(Math.round(weeklyIncome / 7))} / hari
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Total Belanja (7 Hari)
                </span>
                <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-rose-800 tabular-nums">
                {formatRupiah(weeklyExpense)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
                {weeklyExpensesOnly.length} Kali Belanja Stok
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Arus Kas Bersih Mingguan
                </span>
                <div className={`w-7 h-7 rounded-lg border flex items-center justify-center ${
                  weeklyNet >= 0 ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-red-50 border-red-200 text-red-700'
                }`}>
                  {weeklyNet >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                </div>
              </div>
              <div className={`mt-2 text-2xl font-bold tabular-nums ${weeklyNet >= 0 ? 'text-emerald-800' : 'text-rose-700'}`}>
                {formatRupiah(weeklyNet)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2 flex justify-between">
                <span>{weeklyNet >= 0 ? 'Surplus 7 Hari' : 'Defisit 7 Hari'}</span>
                <span className="font-semibold text-stone-700">7 Hari Penuh</span>
              </div>
            </div>
          </div>

          {/* Grafik Batang Perbandingan 7 Hari Berturut-turut */}
          <div className="bg-white p-5 rounded-xl border border-stone-200/80 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center justify-between">
              <span>Aktivitas Kas Harian Selama 1 Minggu</span>
              <span className="text-xs font-normal text-stone-500">
                Hijau: Penjualan | Merah: Belanja
              </span>
            </h3>

            <div className="grid grid-cols-7 gap-2 pt-2">
              {daysOfWeekBreakdown.map((d) => (
                <div key={d.dateStr} className="flex flex-col items-center bg-stone-50 p-2 rounded-lg border border-stone-200/60 text-center">
                  <span className="text-[11px] font-bold text-stone-700 mb-1">{d.label}</span>
                  <div className="w-full flex flex-col gap-1 my-1">
                    <div className="text-[10px] text-emerald-800 font-mono font-bold truncate">
                      {d.income > 0 ? formatRupiah(d.income).replace(',00', '') : '-'}
                    </div>
                    <div className="text-[10px] text-rose-700 font-mono font-bold truncate">
                      {d.expense > 0 ? formatRupiah(d.expense).replace(',00', '') : '-'}
                    </div>
                  </div>
                  <span className={`text-[9px] font-medium px-1 rounded ${
                    d.income >= d.expense ? 'bg-emerald-100 text-emerald-900' : 'bg-rose-100 text-rose-900'
                  }`}>
                    {d.income >= d.expense ? 'Surplus' : 'Defisit'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Rincian Porsi Belanja Grosir Mingguan */}
          <div className="bg-white p-5 rounded-xl border border-stone-200/80 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
              <Store className="w-4 h-4 text-amber-800" />
              <span>Porsi Pengeluaran per Toko Grosir (1 Minggu)</span>
            </h3>

            {weeklyExpense === 0 ? (
              <p className="text-xs text-stone-500 italic py-2">
                Tidak ada belanja stok pada rentang 7 hari ini.
              </p>
            ) : (
              <div className="space-y-2.5">
                {weeklyVendorBreakdown.map((item) => (
                  <div key={item.vendor} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-stone-800">{item.vendor}</span>
                      <span className="font-bold font-mono text-stone-900">
                        {formatRupiah(item.amount)} ({item.percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-amber-500 h-2 rounded-full" style={{ width: `${item.percentage}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODE 3: REKAP 1 BULAN (BULANAN)                          */}
      {/* ======================================================== */}
      {recapMode === 'monthly' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Controls Bar for Monthly */}
          <div className="bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CalendarRange className="w-4 h-4 text-blue-700 shrink-0" />
              <span className="text-xs font-semibold text-stone-700">Pilih Bulan Rekapan:</span>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="px-3 py-1 bg-stone-50 border border-stone-200 rounded-lg text-xs font-bold text-stone-800 cursor-pointer"
              >
                <option value="2026-09">September 2026</option>
                <option value="2026-08">Agustus 2026</option>
                <option value="2026-07">Juli 2026</option>
                <option value="2026-06">Juni 2026</option>
                <option value="2026-05">Mei 2026</option>
                <option value="2026-04">April 2026</option>
                <option value="2026-03">Maret 2026</option>
                <option value="2026-02">Februari 2026</option>
                <option value="2026-01">Januari 2026 (Awal Operasional)</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => exportToCSV(monthlyTransactions, `Rekap-Bulanan-${selectedMonth}.csv`)}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh CSV 1 Bulan</span>
              </button>
            </div>
          </div>

          {/* 3 Metric Cards Bulanan */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Omzet Penjualan 1 Bulan
                </span>
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center">
                  <ArrowDownRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-emerald-800 tabular-nums">
                {formatRupiah(monthlyIncome)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
                Hasil Penjualan Harian Warung
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Total Belanja Stok 1 Bulan
                </span>
                <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-rose-800 tabular-nums">
                {formatRupiah(monthlyExpense)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
                {monthlyExpensesOnly.length} Nota Kulakan Grosir
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Laba Kas Bersih Bulanan
                </span>
                <div className={`w-7 h-7 rounded-lg border flex items-center justify-center ${
                  monthlyNet >= 0 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-red-50 border-red-200 text-red-700'
                }`}>
                  {monthlyNet >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                </div>
              </div>
              <div className={`mt-2 text-2xl font-bold tabular-nums ${monthlyNet >= 0 ? 'text-emerald-800' : 'text-rose-700'}`}>
                {formatRupiah(monthlyNet)}
              </div>
              <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2 flex justify-between">
                <span>{monthlyNet >= 0 ? 'Surplus Bulanan' : 'Defisit Bulanan'}</span>
                <span className="font-semibold text-blue-900">{selectedMonth}</span>
              </div>
            </div>
          </div>

          {/* Rincian Belanja per Minggu (Minggu 1, 2, 3, 4) */}
          <div className="bg-white p-5 rounded-xl border border-stone-200/80 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-blue-800" />
              <span>Rincian Arus Kas per Pekan (Bulan {selectedMonth})</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {monthlyWeeksBreakdown.map((w) => (
                <div key={w.label} className="p-3.5 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1.5">
                  <div className="font-bold text-xs text-stone-800">{w.label}</div>
                  <div className="text-[11px] flex justify-between text-stone-600">
                    <span>Kas Masuk:</span>
                    <span className="font-mono font-bold text-emerald-800">{formatRupiah(w.income)}</span>
                  </div>
                  <div className="text-[11px] flex justify-between text-stone-600">
                    <span>Kas Keluar:</span>
                    <span className="font-mono font-bold text-rose-800">{formatRupiah(w.expense)}</span>
                  </div>
                  <div className="text-[11px] flex justify-between pt-1 border-t border-stone-200 font-bold">
                    <span>Bersih:</span>
                    <span className={w.net >= 0 ? 'text-emerald-800' : 'text-rose-800'}>{formatRupiah(w.net)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Porsi Pengeluaran per Toko Grosir Bulanan */}
          <div className="bg-white p-5 rounded-xl border border-stone-200/80 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
              <Store className="w-4 h-4 text-emerald-800" />
              <span>Porsi Belanja per Toko / Grosir Langganan (1 Bulan)</span>
            </h3>

            {monthlyExpense === 0 ? (
              <p className="text-xs text-stone-500 italic py-2">
                Tidak ada data belanja grosir pada bulan {selectedMonth}.
              </p>
            ) : (
              <div className="space-y-2.5">
                {monthlyVendorBreakdown.map((item) => (
                  <div key={item.vendor} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-stone-800">{item.vendor}</span>
                      <span className="font-bold font-mono text-stone-900">
                        {formatRupiah(item.amount)} ({item.percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-emerald-700 h-2 rounded-full" style={{ width: `${item.percentage}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tabel Nota Belanja Bulanan */}
          <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-stone-50/70 border-b border-stone-100 flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                Daftar Nota Belanja Bulan {selectedMonth}
              </span>
              <span className="text-xs font-mono text-stone-500">
                {monthlyExpensesOnly.length} Nota
              </span>
            </div>

            {monthlyExpensesOnly.length === 0 ? (
              <div className="p-8 text-center text-xs text-stone-500">
                Tidak ada nota belanja pada bulan {selectedMonth}.
              </div>
            ) : (
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50/50 border-b border-stone-100 text-stone-500 uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-4">Tanggal</th>
                    <th className="py-2.5 px-4">Toko / Grosir</th>
                    <th className="py-2.5 px-4 text-right">Nominal Belanja</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {monthlyExpensesOnly.map((tx) => (
                    <tr key={tx.id} className="hover:bg-stone-50/50">
                      <td className="py-2.5 px-4 font-mono text-stone-500">{tx.date}</td>
                      <td className="py-2.5 px-4 font-semibold text-stone-900">
                        Belanja di {tx.category}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold font-mono text-rose-700 tabular-nums">
                        {formatRupiah(tx.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
