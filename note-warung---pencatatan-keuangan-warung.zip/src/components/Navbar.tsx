import React from 'react';
import { WarungIconBadge } from './Ornaments';
import { PlusCircle, LayoutDashboard, BookOpen, Clock, BarChart3, Database, Edit3, FileText, Cookie, ArrowLeft } from 'lucide-react';

export type AppPage = 'dashboard' | 'buku_kas' | 'utang_piutang' | 'rekapitulasi' | 'cadangan';

interface NavbarProps {
  activeTab: AppPage;
  setActiveTab: (tab: AppPage) => void;
  unpaidDebtCount: number;
  warungName: string;
  onOpenEditWarungName: () => void;
  onOpenProposalViewer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  unpaidDebtCount,
  warungName,
  onOpenEditWarungName,
  onOpenProposalViewer,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#1E3A2F] text-amber-50 border-b border-emerald-900/60 shadow-sm">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center justify-between h-16">
        {/* Zone 1: Brand Wordmark with quick rename */}
        <div className="flex items-center gap-2.5">
          <WarungIconBadge />
          <div className="flex items-center gap-1.5 group">
            <button
              type="button"
              onClick={onOpenEditWarungName}
              title="Klik untuk mengubah nama warung"
              className="text-left flex items-center gap-1.5 cursor-pointer hover:opacity-90 transition-opacity"
            >
              <div>
                <span className="font-bold text-sm sm:text-base tracking-tight text-white flex items-center gap-1">
                  <span className="truncate max-w-[130px] sm:max-w-[200px]">{warungName}</span>
                  <Edit3 className="w-3.5 h-3.5 text-amber-300/80 group-hover:text-amber-300 shrink-0" />
                </span>
                <span className="text-[10px] text-emerald-200/80 font-normal -mt-0.5 block">
                  Pencatatan Keuangan Warung
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Zone 2: Navigation Links (Halaman Terpisah) */}
        <nav className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto no-scrollbar py-1">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-emerald-800/95 text-white shadow-xs'
                : 'text-emerald-100/70 hover:text-white hover:bg-emerald-800/40'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Ringkasan</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('buku_kas')}
            className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'buku_kas'
                ? 'bg-emerald-800/95 text-white shadow-xs'
                : 'text-emerald-100/70 hover:text-white hover:bg-emerald-800/40'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Buku Kas</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('utang_piutang')}
            className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'utang_piutang'
                ? 'bg-emerald-800/95 text-white shadow-xs'
                : 'text-emerald-100/70 hover:text-white hover:bg-emerald-800/40'
            }`}
          >
            <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Utang Piutang</span>
            {unpaidDebtCount > 0 && (
              <span className="ml-0.5 px-1.5 py-0.2 bg-amber-400 text-stone-950 font-bold text-[10px] rounded-full">
                {unpaidDebtCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('rekapitulasi')}
            className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'rekapitulasi'
                ? 'bg-emerald-800/95 text-white shadow-xs'
                : 'text-emerald-100/70 hover:text-white hover:bg-emerald-800/40'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Laporan Rekapan</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('cadangan')}
            className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'cadangan'
                ? 'bg-emerald-800/95 text-white shadow-xs'
                : 'text-emerald-100/70 hover:text-white hover:bg-emerald-800/40'
            }`}
          >
            <Database className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Cadangan & Cookies</span>
            <span className="sm:hidden">Cadangan</span>
          </button>
        </nav>

        {/* Zone 3: Exit Arrow / Proposal Link */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={onOpenProposalViewer}
            title="Lihat Dokumen Proposal Pengajuan Sistem"
            className="p-2 text-emerald-200 hover:text-white hover:bg-emerald-800/40 rounded-lg text-xs transition-colors cursor-pointer hidden md:flex items-center gap-1"
          >
            <FileText className="w-4 h-4 text-amber-300" />
            <span className="hidden lg:inline text-xs">Proposal</span>
          </button>

          {activeTab !== 'dashboard' && (
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              title="Keluar ke Ringkasan Utama"
              className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-amber-300 hover:text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-emerald-700/60 shadow-xs"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Keluar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
