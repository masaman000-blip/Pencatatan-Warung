import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType, PRESET_VENDORS, PRESET_INCOME_CATEGORIES } from '../types';
import { formatRupiah, parseRupiahInput, getTodayDateString, getCurrentTimeString } from '../utils/formatters';
import { X, Check, ArrowDownRight, ArrowUpRight, Store, AlertCircle, ArrowLeft } from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Transaction) => void;
  editingTransaction?: Transaction | null;
  defaultType?: TransactionType;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingTransaction,
  defaultType = 'pengeluaran',
}) => {
  const [type, setType] = useState<TransactionType>(defaultType);
  const [rawAmount, setRawAmount] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [time, setTime] = useState<string>(getCurrentTimeString());
  const [category, setCategory] = useState<string>(defaultType === 'pemasukan' ? 'Penjualan Harian Warung' : 'Grosir 36');
  const [customCategory, setCustomCategory] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setRawAmount(String(editingTransaction.amount));
      setDate(editingTransaction.date);
      setTime(editingTransaction.time || getCurrentTimeString());
      setNote(editingTransaction.note || '');

      const isPresetExpense = PRESET_VENDORS.includes(editingTransaction.category as any);
      const isPresetIncome = PRESET_INCOME_CATEGORIES.includes(editingTransaction.category as any);

      if (isPresetExpense || isPresetIncome) {
        setCategory(editingTransaction.category);
        setCustomCategory('');
      } else {
        setCategory('custom');
        setCustomCategory(editingTransaction.category);
      }
    } else {
      // Default reset based on defaultType (Kas Masuk vs Kas Keluar)
      const initialType = defaultType || 'pengeluaran';
      setType(initialType);
      setRawAmount('');
      setDate(getTodayDateString());
      setTime(getCurrentTimeString());
      setCategory(initialType === 'pemasukan' ? 'Penjualan Harian Warung' : 'Grosir 36');
      setCustomCategory('');
      setNote('');
      setErrorMessage('');
    }
  }, [editingTransaction, isOpen, defaultType]);

  if (!isOpen) return null;

  const currentAmount = parseRupiahInput(rawAmount);
  const currentEdits = editingTransaction?.editCount || 0;
  const remainingEdits = Math.max(0, 3 - currentEdits);
  const isLocked = Boolean(editingTransaction && currentEdits >= 3);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '');
    setRawAmount(val);
    if (errorMessage) setErrorMessage('');
  };

  const handleQuickAddAmount = (addAmount: number) => {
    const next = currentAmount + addAmount;
    setRawAmount(String(next));
    if (errorMessage) setErrorMessage('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isLocked) {
      setErrorMessage('Transaksi ini sudah diedit 3 kali dan tidak dapat diubah lagi.');
      return;
    }

    if (currentAmount <= 0) {
      setErrorMessage('Nominal transaksi harus lebih besar dari Rp 0.');
      return;
    }

    if (!date) {
      setErrorMessage('Tanggal transaksi tidak boleh kosong.');
      return;
    }

    const finalCategory =
      type === 'pemasukan'
        ? 'Penjualan Harian Warung'
        : category === 'custom'
        ? customCategory.trim() || 'Lainnya'
        : category;

    const newTx: Transaction = {
      id: editingTransaction ? editingTransaction.id : `tx-${Date.now()}`,
      type,
      amount: currentAmount,
      date,
      time: time || getCurrentTimeString(),
      category: finalCategory,
      note: type === 'pemasukan' ? 'Penjualan Harian Warung' : `Belanja di ${finalCategory}`,
      editCount: editingTransaction ? currentEdits + 1 : 0,
      createdAt: editingTransaction ? editingTransaction.createdAt : Date.now(),
    };

    onSave(newTx);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/70">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              type === 'pemasukan' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
            }`}>
              {type === 'pemasukan' ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base">
                {editingTransaction ? 'Edit Transaksi Kas' : 'Catat Transaksi Baru'}
              </h3>
              <p className="text-[11px] text-stone-500">
                Pencatatan keuangan warung bebas error
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onClose}
              className="flex items-center gap-1 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Keluar</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Edit chances badge / alert */}
          {editingTransaction && (
            <div className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
              isLocked
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : remainingEdits === 1
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}>
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>
                  {isLocked
                    ? 'Batas edit 3 kali telah tercapai. Data tidak dapat diubah lagi.'
                    : `Sisa kesempatan edit: ${remainingEdits} kali lagi (Maksimal 3x).`}
                </span>
              </div>
              <span className="font-bold px-2 py-0.5 rounded bg-white/80 border border-current font-mono text-[10px]">
                {currentEdits}/3 Edit
              </span>
            </div>
          )}

          {/* Error notification banner */}
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Type Selector (Pemasukan vs Pengeluaran) */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1.5 uppercase tracking-wider">
              Jenis Transaksi
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setType('pemasukan');
                  setCategory('Penjualan Harian Warung');
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  type === 'pemasukan'
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-800 ring-2 ring-emerald-600/20'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                <ArrowDownRight className="w-4 h-4 text-emerald-600" />
                <span>Kas Masuk (Penjualan)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setType('pengeluaran');
                  setCategory('Grosir 36');
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  type === 'pengeluaran'
                    ? 'bg-rose-50 border-rose-600 text-rose-800 ring-2 ring-rose-600/20'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 text-rose-600" />
                <span>Kas Keluar (Belanja Stok)</span>
              </button>
            </div>
          </div>

          {/* Nominal Input with Anti-Error & Rupiah formatting */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-stone-700 uppercase tracking-wider">
                Nominal Transaksi (Rp)
              </label>
              {currentAmount > 0 && (
                <span className="text-xs font-bold text-emerald-700 font-mono">
                  {formatRupiah(currentAmount)}
                </span>
              )}
            </div>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-stone-400 text-sm">
                Rp
              </span>
              <input
                type="text"
                inputMode="numeric"
                required
                placeholder="0"
                value={rawAmount ? Number(rawAmount).toLocaleString('id-ID') : ''}
                onChange={handleAmountChange}
                className="w-full pl-11 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-base font-bold text-stone-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 tabular-nums transition-colors"
              />
            </div>

            {/* Quick nominal buttons */}
            <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1 text-xs">
              {[50000, 100000, 250000, 500000, 1000000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => handleQuickAddAmount(amt)}
                  className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-md font-medium text-[11px] whitespace-nowrap cursor-pointer transition-colors"
                >
                  +{formatRupiah(amt).replace(',00', '')}
                </button>
              ))}
            </div>
          </div>

          {/* Toko / Grosir Selection for Pengeluaran or Category for Pemasukan */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1.5 uppercase tracking-wider">
              {type === 'pengeluaran' ? 'Pilihan Toko / Grosir (Vendor)' : 'Kategori Pemasukan'}
            </label>

            {type === 'pengeluaran' ? (
              <div className="space-y-2">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {PRESET_VENDORS.map((vendor) => (
                    <button
                      key={vendor}
                      type="button"
                      onClick={() => {
                        setCategory(vendor);
                        setCustomCategory('');
                      }}
                      className={`p-2 rounded-lg border text-left text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                        category === vendor
                          ? 'bg-amber-50 border-amber-600 text-amber-900 font-semibold ring-1 ring-amber-500'
                          : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      <Store className="w-3.5 h-3.5 shrink-0 text-amber-700" />
                      <span className="truncate">{vendor}</span>
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setCategory('custom')}
                    className={`p-2 rounded-lg border text-left text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                      category === 'custom'
                        ? 'bg-amber-50 border-amber-600 text-amber-900 font-semibold ring-1 ring-amber-500'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <span>+ Nama Toko Lain</span>
                  </button>
                </div>

                {category === 'custom' && (
                  <input
                    type="text"
                    placeholder="Masukkan nama toko/grosir baru..."
                    value={customCategory}
                    onChange={(e) => setCustomCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-amber-600"
                  />
                )}
              </div>
            ) : (
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-600" />
                  <div>
                    <span className="text-xs sm:text-sm font-bold text-emerald-950 block">
                      Penjualan Harian Warung
                    </span>
                    <span className="text-[11px] text-emerald-700 block">
                      Pencatatan seluruh hasil omzet / uang masuk penjualan harian warung
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Tanggal & Waktu Transaksi (Januari 2026 - Seterusnya) */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                Tanggal Transaksi
              </label>
              <input
                type="date"
                required
                min="2026-01-01"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-600/30"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                Jam Transaksi
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-600/30"
              />
            </div>
          </div>

          {/* Footer buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-medium text-stone-600 hover:text-stone-900 rounded-lg hover:bg-stone-100 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs sm:text-sm font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{editingTransaction ? 'Perbarui Transaksi' : 'Simpan Transaksi'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
