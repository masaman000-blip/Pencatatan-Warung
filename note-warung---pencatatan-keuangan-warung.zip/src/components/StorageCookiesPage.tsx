import React, { useState } from 'react';
import { Transaction, DebtRecord } from '../types';
import { exportBackupJSON, exportToCSV } from '../utils/formatters';
import { areCookiesEnabled, getCookie, setCookie } from '../utils/cookies';
import {
  Cookie,
  Database,
  Smartphone,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Check,
  Copy,
  ShieldCheck,
  AlertTriangle,
  ArrowLeft,
} from 'lucide-react';

interface StorageCookiesPageProps {
  transactions: Transaction[];
  debts: DebtRecord[];
  warungId: string;
  warungName: string;
  lastSyncedAt?: number;
  onUpdateWarungId: (newId: string) => void;
  onRestoreData: (restoredTransactions: Transaction[], restoredDebts: DebtRecord[]) => void;
  onManualSync: () => Promise<void>;
  onExit?: () => void;
}

export const StorageCookiesPage: React.FC<StorageCookiesPageProps> = ({
  transactions,
  debts,
  warungId,
  warungName,
  lastSyncedAt,
  onUpdateWarungId,
  onRestoreData,
  onManualSync,
  onExit,
}) => {
  const [inputWarungId, setInputWarungId] = useState(warungId);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const cookiesSupported = areCookiesEnabled();
  const cookieWarungName = getCookie('nw_warung_name') || warungName;
  const cookieWarungId = getCookie('nw_warung_id') || warungId;
  const cookieLastSave = getCookie('nw_last_save_time') || 'Sesi ini';

  const handleCopyCode = () => {
    navigator.clipboard.writeText(warungId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSyncClick = async () => {
    setIsSyncing(true);
    setSyncMessage('');
    try {
      await onManualSync();
      setSyncMessage('Berhasil tersinkronisasi ke server cloud!');
    } catch {
      setSyncMessage('Gagal sinkronisasi. Pastikan terhubung ke internet.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleApplyWarungId = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputWarungId.trim()) {
      onUpdateWarungId(inputWarungId.trim().toLowerCase());
      setSyncMessage(`Kode warung diubah menjadi "${inputWarungId.trim().toLowerCase()}". Mengambil data...`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.transactions && Array.isArray(parsed.transactions)) {
          onRestoreData(parsed.transactions, parsed.debts || []);
          alert(`Berhasil memulihkan ${parsed.transactions.length} transaksi dan ${parsed.debts?.length || 0} catatan utang/piutang.`);
        } else {
          alert('Format file JSON tidak valid.');
        }
      } catch {
        alert('Gagal membaca file cadangan. Pastikan file dalam format JSON yang benar.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetToZero = () => {
    if (window.confirm('Yakin ingin mereset seluruh data catatan keuangan kembali ke angka nol (0)?')) {
      onRestoreData([], []);
      alert('Semua data berhasil direset ke angka nol (0).');
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <Database className="w-5 h-5 text-emerald-800" />
          <div>
            <h2 className="text-base font-bold text-stone-900">
              Pusat Penyimpanan, Cookies & Cadangan Data
            </h2>
            <p className="text-xs text-stone-500">
              Kelola penyimpanan browser, cookies aktif, serta akses pembukuan dari browser mana pun (Chrome, Safari, Edge, Android & iOS).
            </p>
          </div>
        </div>

        {onExit && (
          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 hover:text-stone-900 text-xs font-semibold cursor-pointer transition-colors self-start sm:self-auto"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Keluar ke Ringkasan</span>
          </button>
        )}
      </div>

      {/* Section 1: Sistem Cookies Browser */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center">
              <Cookie className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                Sistem Penyimpanan Cookies Browser
              </h3>
              <span className="text-[11px] text-stone-500">
                Penyimpanan ringan yang berjalan otomatis di peramban web Anda
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>{cookiesSupported ? 'Cookies Aktif' : 'Tersedia'}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-stone-400 block">
              Cookie Nama Warung:
            </span>
            <span className="font-bold text-stone-800 mt-1 block truncate">
              {cookieWarungName}
            </span>
          </div>

          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-stone-400 block">
              Cookie Kode Sinkron:
            </span>
            <span className="font-mono font-bold text-emerald-800 mt-1 block truncate">
              {cookieWarungId}
            </span>
          </div>

          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-stone-400 block">
              Cookie Riwayat Terakhir:
            </span>
            <span className="font-mono text-stone-600 mt-1 block truncate text-[11px]">
              {transactions.length} Transaksi · {debts.length} Kasbon
            </span>
          </div>
        </div>
      </div>

      {/* Section 2: Akses Lintas Browser / Cloud Sync */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-900 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                Akses dari Browser Mana Saja (Chrome, Safari, HP & Laptop)
              </h3>
              <span className="text-[11px] text-stone-500">
                Gunakan Kode Warung yang sama untuk membuka pembukuan yang tersinkronisasi
              </span>
            </div>
          </div>
        </div>

        <p className="text-xs text-stone-600">
          Untuk membuka data warung ini di browser lain (misal Google Chrome di laptop kasir atau Safari di HP), cukup gunakan <strong>Kode Warung</strong> di bawah ini:
        </p>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="flex-1 bg-stone-50 border border-stone-300 px-3.5 py-2.5 rounded-xl font-mono font-bold text-stone-900 text-sm flex items-center justify-between">
            <span>{warungId}</span>
            <button
              type="button"
              onClick={handleCopyCode}
              className="text-xs text-emerald-800 hover:text-emerald-950 font-sans font-semibold flex items-center gap-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tersalin' : 'Salin Kode'}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleSyncClick}
            disabled={isSyncing}
            className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}</span>
          </button>
        </div>

        {/* Change warung code form */}
        <form onSubmit={handleApplyWarungId} className="pt-2 border-t border-stone-100 flex items-center gap-2 text-xs">
          <span className="text-stone-500 whitespace-nowrap">Ganti Kode Warung:</span>
          <input
            type="text"
            placeholder="Contoh: warung-berkah-01"
            value={inputWarungId}
            onChange={(e) => setInputWarungId(e.target.value)}
            className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
          />
          <button
            type="submit"
            className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-lg font-semibold cursor-pointer"
          >
            Terapkan
          </button>
        </form>

        {syncMessage && (
          <div className="text-xs text-emerald-800 font-medium flex items-center gap-1.5 pt-1">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{syncMessage}</span>
          </div>
        )}
      </div>

      {/* Section 3: Unduh File Cadangan (JSON & Excel CSV) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-xs space-y-2.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Cadangan Lengkap (.JSON)</span>
            </div>
            <p className="text-xs text-stone-500 mt-1">
              File backup lengkap berisi seluruh transaksi kas, catatan kasbon, dan pengaturan warung.
            </p>
          </div>
          <button
            type="button"
            onClick={() => exportBackupJSON(transactions, debts)}
            className="w-full py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-semibold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Unduh File Cadangan (.JSON)</span>
          </button>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-xs space-y-2.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
              <Download className="w-4 h-4 text-amber-700" />
              <span>Ekspor Rekap Excel (.CSV)</span>
            </div>
            <p className="text-xs text-stone-500 mt-1">
              Bisa langsung dibuka di Microsoft Excel atau Google Sheets untuk laporan keuangan warung.
            </p>
          </div>
          <button
            type="button"
            onClick={() => exportToCSV(transactions, `Laporan-Kas-${warungName}.csv`)}
            className="w-full py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-semibold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Unduh Laporan Excel (.CSV)</span>
          </button>
        </div>
      </div>

      {/* Section 4: Pulihkan Cadangan (Restore) & Reset Nol */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-xs space-y-4">
        <div>
          <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
            <Upload className="w-4 h-4 text-blue-700" />
            <span>Pulihkan Data dari File Cadangan (Restore)</span>
          </div>
          <p className="text-xs text-stone-500 mt-1">
            Unggah file backup `.json` yang pernah Anda unduh sebelumnya untuk mengembalikan catatan keuangan:
          </p>
          <div className="mt-2.5">
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="block w-full text-xs text-stone-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-stone-100 file:text-stone-800 hover:file:bg-stone-200 cursor-pointer"
            />
          </div>
        </div>

        {/* Reset to zero */}
        <div className="pt-3 border-t border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold text-red-900 block">
              Mulai Ulang / Bersihkan Data
            </span>
            <span className="text-[11px] text-stone-500">
              Kosongkan semua transaksi dan kasbon kembali ke angka nol (0)
            </span>
          </div>
          <button
            type="button"
            onClick={handleResetToZero}
            className="px-3.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-lg text-xs font-semibold cursor-pointer whitespace-nowrap self-start sm:self-auto"
          >
            Reset Semua ke Nol (0)
          </button>
        </div>
      </div>
    </div>
  );
};
