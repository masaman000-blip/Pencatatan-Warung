import React from 'react';

/**
 * Subtle traditional Indonesian geometric motif ornaments (Kawung & Tenun accents)
 * Clean, lightweight SVG accents designed to add an authentic warm warung touch without visual clutter.
 */

export function BatikBorderAccent({ className = '' }: { className?: string }) {
  return (
    <div className={`w-full overflow-hidden flex items-center justify-center opacity-30 select-none pointer-events-none ${className}`}>
      <svg
        width="100%"
        height="8"
        viewBox="0 0 400 8"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="repeat-x"
        className="w-full text-amber-800"
      >
        <pattern id="batik-pattern" x="0" y="0" width="24" height="8" patternUnits="userSpaceOnUse">
          <path
            d="M0 4 Q6 0, 12 4 Q18 8, 24 4"
            stroke="currentColor"
            strokeWidth="1.2"
            fill="none"
          />
          <circle cx="12" cy="4" r="1" fill="currentColor" />
          <path
            d="M0 4 Q6 8, 12 4 Q18 0, 24 4"
            stroke="currentColor"
            strokeWidth="0.8"
            strokeDasharray="1 2"
            fill="none"
          />
        </pattern>
        <rect width="100%" height="8" fill="url(#batik-pattern)" />
      </svg>
    </div>
  );
}

export function WarungIconBadge({ className = '' }: { className?: string }) {
  return (
    <div className={`inline-flex items-center justify-center relative ${className}`}>
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="2" y="2" width="32" height="32" rx="8" fill="#1E3A2F" />
        {/* Subtle inner geometric border */}
        <rect x="4.5" y="4.5" width="27" height="27" rx="6" stroke="#C2A15D" strokeWidth="1" strokeDasharray="3 2" />
        {/* Traditional Warung Roof / Shopfront Shape */}
        <path d="M9 14L18 8L27 14V25C27 25.5523 26.5523 26 26 26H10C9.44772 26 9 25.5523 9 25V14Z" fill="#2E5544" />
        <path d="M7 14L18 6L29 14" stroke="#F5D061" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        {/* Awning stripes */}
        <path d="M12 14V19C12 19.5 13 20 14 19V14" fill="#F5D061" />
        <path d="M16 14V19C16 19.5 17 20 18 19V14" fill="#FFFFFF" opacity="0.9" />
        <path d="M20 14V19C20 19.5 21 20 22 19V14" fill="#F5D061" />
        {/* Counter / Door */}
        <rect x="14" y="20" width="8" height="6" rx="1" fill="#FBF9F5" />
      </svg>
    </div>
  );
}

export function CornerOrnament({ className = '' }: { className?: string }) {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`opacity-20 select-none pointer-events-none ${className}`}
    >
      <path d="M2 22V6C2 3.79086 3.79086 2 6 2H22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="6" cy="6" r="2" fill="currentColor" />
    </svg>
  );
}
