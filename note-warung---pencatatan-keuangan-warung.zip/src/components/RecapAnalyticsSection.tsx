import React, { useState } from 'react';
import { Transaction, PRESET_VENDORS } from '../types';
import { formatRupiah, exportToCSV } from '../utils/formatters';
import { BarChart3, Calendar, Download, Store, TrendingDown, ArrowUpRight } from 'lucide-react';
import { BatikBorderAccent } from './Ornaments';

interface RecapAnalyticsSectionProps {
  transactions: Transaction[];
  warungName: string;
}

export const RecapAnalyticsSection: React.FC<RecapAnalyticsSectionProps> = ({
  transactions,
  warungName,
}) => {
  const [selectedMonth, setSelectedMonth] = useState('2026-09');

  // Filter expenses for last 7 days
  const now = new Date('2026-09-24T23:59:59'); // Base anchor matching proposal date
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const weeklyExpenses = transactions.filter((t) => {
    if (t.type !== 'pengeluaran') return false;
    const txDate = new Date(t.date);
    return txDate >= sevenDaysAgo && txDate <= now;
  });

  const totalWeeklyExpense = weeklyExpenses.reduce((sum, t) => sum + t.amount, 0);

  // Filter expenses for selected month
  const monthlyExpenses = transactions.filter((t) => {
    return t.type === 'pengeluaran' && t.date.startsWith(selectedMonth);
  });

  const totalMonthlyExpense = monthlyExpenses.reduce((sum, t) => sum + t.amount, 0);

  interface VendorSummary {
    vendor: string;
    amount: number;
    count: number;
    percentage: number;
  }

  // Breakdown by vendor for chosen month
  const vendorBreakdown: VendorSummary[] = PRESET_VENDORS.map((vendor) => {
    const matching = monthlyExpenses.filter((t) => t.category === vendor);
    const amount = matching.reduce((sum, t) => sum + t.amount, 0);
    const percentage = totalMonthlyExpense > 0 ? (amount / totalMonthlyExpense) * 100 : 0;
    return {
      vendor,
      amount,
      count: matching.length,
      percentage: Math.round(percentage),
    };
  });

  // Also include custom vendors
  const otherExpenses = monthlyExpenses.filter(
    (t) => !PRESET_VENDORS.includes(t.category as any)
  );
  if (otherExpenses.length > 0) {
    const otherAmount = otherExpenses.reduce((sum, t) => sum + t.amount, 0);
    const otherPct = totalMonthlyExpense > 0 ? (otherAmount / totalMonthlyExpense) * 100 : 0;
    vendorBreakdown.push({
      vendor: 'Vendor Tambahan / Khusus',
      amount: otherAmount,
      count: otherExpenses.length,
      percentage: Math.round(otherPct),
    });
  }

  // Breakdown by vendor for 7-day period
  const weeklyVendorBreakdown = PRESET_VENDORS.map((vendor) => {
    const matching = weeklyExpenses.filter((t) => t.category === vendor);
    const amount = matching.reduce((sum, t) => sum + t.amount, 0);
    const percentage = totalWeeklyExpense > 0 ? (amount / totalWeeklyExpense) * 100 : 0;
    return {
      vendor,
      amount,
      count: matching.length,
      percentage: Math.round(percentage),
    };
  });

  const handleExportMonthCSV = () => {
    exportToCSV(monthlyExpenses, `Rekap-Belanja-${selectedMonth}.csv`);
  };

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="bg-white p-5 rounded-xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-800" />
            <h2 className="text-base font-bold text-stone-900">
              Rekapitulasi Pengeluaran Mingguan & Bulanan
            </h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Laporan otomatis belanja stok barang warung berdasarkan vendor toko grosir langganan
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-stone-50 px-3 py-1.5 rounded-lg border border-stone-200 text-xs">
            <Calendar className="w-3.5 h-3.5 text-stone-500" />
            <span className="text-stone-500 font-medium">Bulan Rekap:</span>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent font-bold text-stone-800 focus:outline-hidden cursor-pointer"
            >
              <option value="2026-09">September 2026</option>
              <option value="2026-08">Agustus 2026</option>
              <option value="2026-07">Juli 2026</option>
              <option value="2026-06">Juni 2026</option>
              <option value="2026-05">Mei 2026</option>
              <option value="2026-04">April 2026</option>
              <option value="2026-03">Maret 2026</option>
              <option value="2026-02">Februari 2026</option>
              <option value="2026-01">Januari 2026</option>
            </select>
          </div>

          <button
            type="button"
            onClick={handleExportMonthCSV}
            className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Unduh CSV</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Section 1: Rekap 1 Minggu (7 Hari Terakhir) */}
        <div className="bg-white rounded-xl border border-stone-200/80 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div>
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider block">
                  Rekap 7 Hari Terakhir
                </span>
                <span className="text-lg font-bold text-stone-900">
                  {formatRupiah(totalWeeklyExpense)}
                </span>
              </div>
              <span className="text-[11px] bg-amber-50 text-amber-800 font-medium px-2 py-1 rounded border border-amber-200">
                {weeklyExpenses.length} Kali Belanja
              </span>
            </div>

            {/* Breakdown per vendor */}
            <div className="mt-4 space-y-3">
              <span className="text-xs font-semibold text-stone-700 block">
                Rincian Belanja per Toko/Grosir (7 Hari):
              </span>

              {weeklyVendorBreakdown.map((item) => (
                <div key={item.vendor} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-stone-800">{item.vendor}</span>
                    <span className="font-bold text-stone-900 tabular-nums">
                      {formatRupiah(item.amount)}
                      <span className="text-[11px] text-stone-400 font-normal ml-1">
                        ({item.percentage}%)
                      </span>
                    </span>
                  </div>
                  {/* Progress bar */}
                  <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-amber-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-500 flex justify-between">
            <span>Rentang: 18 Sep 2026 s/d 24 Sep 2026</span>
            <span className="font-medium text-amber-800">Minggu Berjalan</span>
          </div>
        </div>

        {/* Section 2: Rekap 1 Bulan Penuh (Monthly Recap) */}
        <div className="bg-white rounded-xl border border-stone-200/80 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div>
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider block">
                  Rekap Bulanan ({selectedMonth})
                </span>
                <span className="text-lg font-bold text-stone-900">
                  {formatRupiah(totalMonthlyExpense)}
                </span>
              </div>
              <span className="text-[11px] bg-emerald-50 text-emerald-800 font-medium px-2 py-1 rounded border border-emerald-200">
                {monthlyExpenses.length} Total Belanja
              </span>
            </div>

            {/* Breakdown per vendor */}
            <div className="mt-4 space-y-3">
              <span className="text-xs font-semibold text-stone-700 block">
                Porsi Pengeluaran per Kategori Toko:
              </span>

              {vendorBreakdown.map((item) => (
                <div key={item.vendor} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-stone-800">{item.vendor}</span>
                    <span className="font-bold text-stone-900 tabular-nums">
                      {formatRupiah(item.amount)}
                      <span className="text-[11px] text-stone-400 font-normal ml-1">
                        ({item.percentage}%)
                      </span>
                    </span>
                  </div>
                  {/* Progress bar */}
                  <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-700 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-500 flex justify-between">
            <span>Kontrol biaya operasional & kulakan grosir</span>
            <span className="font-medium text-emerald-800">1 Bulan Penuh</span>
          </div>
        </div>
      </div>

      {/* Rincian Tabel Belanja Grosir Bulan Ini */}
      <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
        <div className="px-5 py-3 border-b border-stone-100 bg-stone-50/60 flex items-center justify-between">
          <h3 className="font-bold text-stone-800 text-sm">
            Daftar Nota Belanja Bulan {selectedMonth}
          </h3>
          <span className="text-xs text-stone-500 font-mono">
            {monthlyExpenses.length} Nota
          </span>
        </div>

        {monthlyExpenses.length === 0 ? (
          <div className="p-8 text-center text-xs text-stone-500">
            Tidak ada transaksi pengeluaran pada bulan ini.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50/80 border-b border-stone-100 text-stone-500 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-4">Tanggal</th>
                  <th className="py-2.5 px-4">Toko / Grosir</th>
                  <th className="py-2.5 px-4 text-right">Nominal Belanja</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-stone-700">
                {monthlyExpenses.map((tx) => (
                  <tr key={tx.id} className="hover:bg-stone-50/60">
                    <td className="py-2.5 px-4 font-mono text-[11px] whitespace-nowrap">
                      {tx.date} {tx.time ? `· ${tx.time}` : ''}
                    </td>
                    <td className="py-2.5 px-4 font-semibold text-stone-900 whitespace-nowrap">
                      Belanja di {tx.category}
                    </td>
                    <td className="py-2.5 px-4 text-right font-bold font-mono text-rose-700 whitespace-nowrap">
                      {formatRupiah(tx.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
