import React from 'react';
import { Transaction, DebtRecord } from '../types';
import { formatRupiah, formatTanggalIndo } from '../utils/formatters';
import { DashboardStats } from './DashboardStats';
import {
  PlusCircle,
  BookOpen,
  Clock,
  BarChart3,
  Cookie,
  ShieldCheck,
  ArrowRight,
  TrendingUp,
  Store,
  Wallet,
} from 'lucide-react';
import { BatikBorderAccent } from './Ornaments';
import { areCookiesEnabled } from '../utils/cookies';

interface DashboardPageProps {
  transactions: Transaction[];
  debts: DebtRecord[];
  warungName: string;
  onNavigateTab: (tab: 'buku_kas' | 'utang_piutang' | 'rekapitulasi' | 'cadangan', type?: 'pemasukan' | 'pengeluaran') => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  transactions,
  debts,
  warungName,
  onNavigateTab,
}) => {
  const cookiesActive = areCookiesEnabled();

  // Today calculations
  const todayStr = '2026-09-24';
  const todayTxs = transactions.filter((t) => t.date === todayStr);
  const todayIncome = todayTxs.filter((t) => t.type === 'pemasukan').reduce((s, t) => s + t.amount, 0);
  const todayExpense = todayTxs.filter((t) => t.type === 'pengeluaran').reduce((s, t) => s + t.amount, 0);

  const activeDebtCount = debts.filter((d) => d.status !== 'lunas').length;
  const activeDebtAmount = debts
    .filter((d) => d.type === 'piutang' && d.status !== 'lunas')
    .reduce((s, d) => s + (d.totalAmount - d.paidAmount), 0);

  return (
    <div className="space-y-5">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#1E3A2F] to-[#142921] text-white p-5 sm:p-6 rounded-2xl shadow-sm relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-900/60 border border-emerald-700/50">
              Panel Utama Warung
            </span>
            <span className="text-xs text-emerald-200">
              {formatTanggalIndo(todayStr)}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            Selamat Datang di {warungName}
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/80 max-w-xl">
            Sistem pembukuan keuangan warung yang bersih, rapi, dan bebas error. Semua catatan kas dan utang piutang tersimpan otomatis di browser & cookies.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onNavigateTab('buku_kas')}
            className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-stone-950" />
            <span>Buka Buku Kas & Transaksi →</span>
          </button>
        </div>
      </div>

      {/* Main Real-time Summary Cards & Peak Analytics */}
      <DashboardStats
        transactions={transactions}
        filteredTransactions={transactions}
        selectedPeriodLabel="Semua Waktu Operasional"
        onSelectType={(type) => onNavigateTab('buku_kas', type)}
      />

      {/* Quick Navigation Cards (Halaman-halaman Terpisah) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Card Buku Kas */}
        <div
          onClick={() => onNavigateTab('buku_kas')}
          className="p-4 bg-white hover:bg-stone-50/80 rounded-xl border border-stone-200/80 shadow-xs cursor-pointer transition-all hover:border-emerald-500/50 group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-emerald-700 transition-colors" />
          </div>
          <h3 className="font-bold text-sm text-stone-900">Buku Kas & Transaksi</h3>
          <p className="text-xs text-stone-500 mt-1">
            Lihat riwayat transaksi kas masuk/keluar, filter per tanggal Januari 2026 ke depan, dan cetak struk.
          </p>
          <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] font-medium text-emerald-800">
            <span>{transactions.length} Total Transaksi</span>
            <span>Buka Halaman →</span>
          </div>
        </div>

        {/* Card Utang Piutang */}
        <div
          onClick={() => onNavigateTab('utang_piutang')}
          className="p-4 bg-white hover:bg-stone-50/80 rounded-xl border border-stone-200/80 shadow-xs cursor-pointer transition-all hover:border-amber-500/50 group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-amber-700 transition-colors" />
          </div>
          <h3 className="font-bold text-sm text-stone-900">Buku Utang & Piutang</h3>
          <p className="text-xs text-stone-500 mt-1">
            Pantau kasbon pelanggan dan utang tempo grosir, catat cicilan, dan kirim pengingat WhatsApp.
          </p>
          <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] font-medium text-amber-800">
            <span>{activeDebtCount} Kasbon Belum Lunas</span>
            <span>Buka Halaman →</span>
          </div>
        </div>

        {/* Card Laporan Rekapan */}
        <div
          onClick={() => onNavigateTab('rekapitulasi')}
          className="p-4 bg-white hover:bg-stone-50/80 rounded-xl border border-stone-200/80 shadow-xs cursor-pointer transition-all hover:border-blue-500/50 group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-blue-700 transition-colors" />
          </div>
          <h3 className="font-bold text-sm text-stone-900">Laporan Rekapan Teliti</h3>
          <p className="text-xs text-stone-500 mt-1">
            Rekapitulasi otomatis dalam 1 Hari, 1 Minggu, dan 1 Bulan lengkap dengan porsi belanja grosir.
          </p>
          <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] font-medium text-blue-800">
            <span>1 Hari · 1 Minggu · 1 Bulan</span>
            <span>Buka Halaman →</span>
          </div>
        </div>
      </div>

      {/* Cookies & Storage Status Indicator */}
      <div className="bg-[#FAF8F3] border border-amber-200/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
            <Cookie className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 font-bold text-stone-800">
              <span>Sistem Penyimpanan Cookies & LocalStorage Browser:</span>
              <span className="text-emerald-700 flex items-center gap-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                {cookiesActive ? 'Aktif & Aman' : 'Tersedia'}
              </span>
            </div>
            <p className="text-[11px] text-stone-600 mt-0.5">
              Identitas warung, catatan kas, dan utang piutang otomatis terlindungi dalam sesi browser dan cookie aktif.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigateTab('cadangan')}
          className="px-3 py-1.5 bg-white hover:bg-stone-100 text-stone-800 font-semibold border border-stone-300 rounded-lg text-xs self-start sm:self-auto cursor-pointer"
        >
          Kelola Cadangan & Cookies
        </button>
      </div>
    </div>
  );
};
