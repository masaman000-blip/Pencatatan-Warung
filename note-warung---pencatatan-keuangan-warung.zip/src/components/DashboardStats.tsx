import React from 'react';
import { Transaction } from '../types';
import { formatRupiah, formatTanggalIndo } from '../utils/formatters';
import { TrendingUp, TrendingDown, Wallet, Award, ArrowUpRight, ArrowDownRight, ShieldCheck } from 'lucide-react';
import { BatikBorderAccent, CornerOrnament } from './Ornaments';

interface DashboardStatsProps {
  transactions: Transaction[];
  filteredTransactions: Transaction[];
  selectedPeriodLabel: string;
  onSelectType?: (type: 'pemasukan' | 'pengeluaran') => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({
  transactions,
  filteredTransactions,
  selectedPeriodLabel,
  onSelectType,
}) => {
  // All-time totals for current balance
  const totalAllIncome = transactions
    .filter((t) => t.type === 'pemasukan')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalAllExpense = transactions
    .filter((t) => t.type === 'pengeluaran')
    .reduce((sum, t) => sum + t.amount, 0);

  const currentCashBalance = totalAllIncome - totalAllExpense;

  // Filtered period totals
  const periodIncome = filteredTransactions
    .filter((t) => t.type === 'pemasukan')
    .reduce((sum, t) => sum + t.amount, 0);

  const periodExpense = filteredTransactions
    .filter((t) => t.type === 'pengeluaran')
    .reduce((sum, t) => sum + t.amount, 0);

  const periodNetFlow = periodIncome - periodExpense;

  // Peak Financial Analysis (Analisis Puncak Keuangan dari Proposal)
  const peakIncome = transactions
    .filter((t) => t.type === 'pemasukan')
    .reduce<Transaction | null>((max, t) => (!max || t.amount > max.amount ? t : max), null);

  const peakExpense = transactions
    .filter((t) => t.type === 'pengeluaran')
    .reduce<Transaction | null>((max, t) => (!max || t.amount > max.amount ? t : max), null);

  return (
    <div className="space-y-4">
      {/* Saldo Kas & Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Saldo Kas Saat Ini */}
        <div className="relative bg-gradient-to-br from-[#1E3A2F] to-[#142921] text-amber-50 p-4 rounded-xl border border-emerald-950/40 shadow-sm overflow-hidden flex flex-col justify-between">
          <CornerOrnament className="absolute top-2 right-2 text-amber-300" />
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-emerald-200/90 tracking-wide uppercase">
                Saldo Kas Saat Ini
              </span>
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center">
                <Wallet className="w-4 h-4 text-emerald-300" />
              </div>
            </div>
            <div className="mt-2 text-2xl font-bold tracking-tight text-white tabular-nums">
              {formatRupiah(currentCashBalance)}
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-emerald-800/60 flex items-center justify-between text-[11px] text-emerald-200/70">
            <span>Kas Masuk - Kas Keluar</span>
            <span className="flex items-center gap-1 text-emerald-300 font-medium">
              <ShieldCheck className="w-3 h-3" /> Real-time
            </span>
          </div>
        </div>

        {/* Card 2: Pemasukan Periode */}
        <div
          onClick={() => onSelectType?.('pemasukan')}
          className={`relative bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between transition-all ${
            onSelectType ? 'cursor-pointer hover:border-emerald-500 hover:shadow-sm group' : ''
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-stone-500 tracking-wide uppercase group-hover:text-emerald-800 transition-colors">
                Pemasukan (Kas Masuk)
              </span>
              <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <ArrowDownRight className="w-4 h-4 text-emerald-600 group-hover:text-white transition-colors" />
              </div>
            </div>
            <div className="mt-2 text-2xl font-bold tracking-tight text-stone-900 tabular-nums">
              {formatRupiah(periodIncome)}
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
            <span className="truncate">{selectedPeriodLabel}</span>
            <span className="text-emerald-700 font-medium font-mono text-[10px]">
              {filteredTransactions.filter((t) => t.type === 'pemasukan').length} Transaksi
            </span>
          </div>
        </div>

        {/* Card 3: Pengeluaran Periode */}
        <div
          onClick={() => onSelectType?.('pengeluaran')}
          className={`relative bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between transition-all ${
            onSelectType ? 'cursor-pointer hover:border-rose-500 hover:shadow-sm group' : ''
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-stone-500 tracking-wide uppercase group-hover:text-rose-800 transition-colors">
                Pengeluaran (Kas Keluar)
              </span>
              <div className="w-7 h-7 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors">
                <ArrowUpRight className="w-4 h-4 text-rose-600 group-hover:text-white transition-colors" />
              </div>
            </div>
            <div className="mt-2 text-2xl font-bold tracking-tight text-stone-900 tabular-nums">
              {formatRupiah(periodExpense)}
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
            <span className="truncate">Belanja stok & operasional</span>
            <span className="text-rose-700 font-medium font-mono text-[10px]">
              {filteredTransactions.filter((t) => t.type === 'pengeluaran').length} Transaksi
            </span>
          </div>
        </div>

        {/* Card 4: Arus Kas Bersih Periode */}
        <div className="relative bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-stone-500 tracking-wide uppercase">
                Arus Kas Bersih
              </span>
              <div className={`w-7 h-7 rounded-lg border flex items-center justify-center ${
                periodNetFlow >= 0 ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-red-50 border-red-200 text-red-600'
              }`}>
                {periodNetFlow >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              </div>
            </div>
            <div className={`mt-2 text-2xl font-bold tracking-tight tabular-nums ${
              periodNetFlow >= 0 ? 'text-emerald-700' : 'text-rose-600'
            }`}>
              {formatRupiah(periodNetFlow)}
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
            <span>Surplus / Defisit</span>
            <span className={`font-semibold ${periodNetFlow >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
              {periodNetFlow >= 0 ? 'Surplus Kas' : 'Defisit Kas'}
            </span>
          </div>
        </div>
      </div>

      {/* Analisis Puncak Keuangan (Fitur 5 dari Proposal Spesifikasi) */}
      <div className="bg-[#FAF7F0] border border-amber-200/70 rounded-xl p-3.5 relative overflow-hidden">
        <BatikBorderAccent className="mb-2" />
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-700" />
            <h2 className="text-xs font-bold text-stone-800 tracking-wider uppercase">
              Analisis Puncak Keuangan (Rekor Warung)
            </h2>
          </div>
          <span className="text-[11px] text-stone-500 hidden sm:inline">
            Deteksi otomatis transaksi tertinggi sepanjang operasional
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Rekor Pemasukan Tertinggi */}
          <div className="bg-white/90 backdrop-blur-xs p-3 rounded-lg border border-amber-100 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-stone-500 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>Pemasukan Tertinggi</span>
              </div>
              <div className="mt-1 text-lg font-bold text-emerald-800 tabular-nums">
                {peakIncome ? formatRupiah(peakIncome.amount) : 'Rp 0'}
              </div>
              <p className="text-[11px] text-stone-600 mt-0.5 line-clamp-1">
                {peakIncome?.note || 'Belum ada transaksi'}
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[10px] bg-emerald-50 text-emerald-800 font-medium px-2 py-0.5 rounded border border-emerald-200">
                {peakIncome ? formatTanggalIndo(peakIncome.date, { short: true }) : '-'}
              </span>
              <div className="text-[10px] text-stone-400 mt-1 font-mono">
                {peakIncome?.time || ''}
              </div>
            </div>
          </div>

          {/* Rekor Pengeluaran Tertinggi */}
          <div className="bg-white/90 backdrop-blur-xs p-3 rounded-lg border border-amber-100 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-stone-500 font-medium">
                <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                <span>Pengeluaran Tertinggi (Belanja Terbesar)</span>
              </div>
              <div className="mt-1 text-lg font-bold text-rose-800 tabular-nums">
                {peakExpense ? formatRupiah(peakExpense.amount) : 'Rp 0'}
              </div>
              <p className="text-[11px] text-stone-600 mt-0.5 line-clamp-1">
                {peakExpense ? `${peakExpense.category}: ${peakExpense.note}` : 'Belum ada belanja'}
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[10px] bg-rose-50 text-rose-800 font-medium px-2 py-0.5 rounded border border-rose-200">
                {peakExpense ? formatTanggalIndo(peakExpense.date, { short: true }) : '-'}
              </span>
              <div className="text-[10px] text-stone-400 mt-1 font-mono">
                {peakExpense?.time || ''}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
