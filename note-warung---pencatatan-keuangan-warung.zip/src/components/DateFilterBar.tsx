import React from 'react';
import { Search, Calendar, Filter, X, RotateCcw } from 'lucide-react';
import { PRESET_VENDORS } from '../types';

export interface FilterState {
  periodType: 'all' | 'today' | 'week' | 'month' | 'custom' | string; // string for specific month '2026-01', etc.
  startDate: string;
  endDate: string;
  searchQuery: string;
  categoryFilter: string;
  typeFilter: 'all' | 'pemasukan' | 'pengeluaran';
}

interface DateFilterBarProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onResetFilters: () => void;
}

export const MONTH_OPTIONS = [
  { value: 'all', label: 'Semua Periode (Sejak Jan 2026)' },
  { value: 'today', label: 'Hari Ini' },
  { value: 'week', label: '7 Hari Terakhir' },
  { value: 'month', label: 'Bulan Ini (September 2026)' },
  { value: '2026-09', label: 'September 2026' },
  { value: '2026-08', label: 'Agustus 2026' },
  { value: '2026-07', label: 'Juli 2026' },
  { value: '2026-06', label: 'Juni 2026' },
  { value: '2026-05', label: 'Mei 2026' },
  { value: '2026-04', label: 'April 2026' },
  { value: '2026-03', label: 'Maret 2026' },
  { value: '2026-02', label: 'Februari 2026' },
  { value: '2026-01', label: 'Januari 2026 (Awal Operasional)' },
  { value: 'custom', label: 'Rentang Tanggal Khusus...' },
];

export const DateFilterBar: React.FC<DateFilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
}) => {
  const isFiltered =
    filters.periodType !== 'all' ||
    filters.searchQuery !== '' ||
    filters.categoryFilter !== 'all' ||
    filters.typeFilter !== 'all';

  return (
    <div className="bg-white rounded-xl border border-stone-200/80 p-3.5 shadow-xs space-y-3">
      {/* Row 1: Search & Type Segmented Control */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search bar */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari transaksi, toko/grosir, atau catatan belanja..."
            value={filters.searchQuery}
            onChange={(e) => onFilterChange({ ...filters, searchQuery: e.target.value })}
            className="w-full pl-9 pr-8 py-2 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 transition-colors"
          />
          {filters.searchQuery && (
            <button
              onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Transaction Type Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg shrink-0">
          <button
            type="button"
            onClick={() => onFilterChange({ ...filters, typeFilter: 'all' })}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filters.typeFilter === 'all'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Semua
          </button>
          <button
            type="button"
            onClick={() => onFilterChange({ ...filters, typeFilter: 'pemasukan' })}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filters.typeFilter === 'pemasukan'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-emerald-800 hover:text-emerald-950'
            }`}
          >
            Kas Masuk
          </button>
          <button
            type="button"
            onClick={() => onFilterChange({ ...filters, typeFilter: 'pengeluaran' })}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filters.typeFilter === 'pengeluaran'
                ? 'bg-rose-700 text-white shadow-xs'
                : 'text-rose-800 hover:text-rose-950'
            }`}
          >
            Kas Keluar
          </button>
        </div>
      </div>

      {/* Row 2: Date Selector & Category Dropdowns */}
      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100 text-xs">
        {/* Period Selector (Januari 2026 - Seterusnya) */}
        <div className="flex items-center gap-1.5 bg-stone-50 px-2.5 py-1.5 rounded-lg border border-stone-200 shrink-0">
          <Calendar className="w-3.5 h-3.5 text-stone-500" />
          <span className="text-stone-500 font-medium">Periode:</span>
          <select
            value={filters.periodType}
            onChange={(e) => onFilterChange({ ...filters, periodType: e.target.value })}
            className="bg-transparent font-semibold text-stone-800 focus:outline-hidden cursor-pointer"
          >
            {MONTH_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        {/* Custom Date Range if chosen */}
        {filters.periodType === 'custom' && (
          <div className="flex items-center gap-1.5 bg-amber-50/60 p-1 rounded-lg border border-amber-200">
            <input
              type="date"
              min="2026-01-01"
              value={filters.startDate}
              onChange={(e) => onFilterChange({ ...filters, startDate: e.target.value })}
              className="px-2 py-1 bg-white border border-stone-200 rounded text-xs text-stone-700"
            />
            <span className="text-stone-400">s/d</span>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => onFilterChange({ ...filters, endDate: e.target.value })}
              className="px-2 py-1 bg-white border border-stone-200 rounded text-xs text-stone-700"
            />
          </div>
        )}

        {/* Filter by Toko/Grosir or Category */}
        <div className="flex items-center gap-1.5 bg-stone-50 px-2.5 py-1.5 rounded-lg border border-stone-200 shrink-0">
          <Filter className="w-3.5 h-3.5 text-stone-500" />
          <span className="text-stone-500 font-medium">Toko/Kategori:</span>
          <select
            value={filters.categoryFilter}
            onChange={(e) => onFilterChange({ ...filters, categoryFilter: e.target.value })}
            className="bg-transparent font-medium text-stone-800 focus:outline-hidden cursor-pointer"
          >
            <option value="all">Semua Kategori & Toko</option>
            <optgroup label="Toko & Grosir Terintegrasi">
              {PRESET_VENDORS.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </optgroup>
            <optgroup label="Pemasukan">
              <option value="Penjualan Harian Warung">Penjualan Harian Warung</option>
            </optgroup>
          </select>
        </div>

        {/* Reset filter button if any filter active */}
        {isFiltered && (
          <button
            type="button"
            onClick={onResetFilters}
            className="ml-auto text-xs text-amber-800 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 px-2.5 py-1.5 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filter</span>
          </button>
        )}
      </div>
    </div>
  );
};
