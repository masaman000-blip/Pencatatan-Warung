import React, { useState } from 'react';
import { Transaction, DebtRecord } from '../types';
import { exportBackupJSON, exportToCSV } from '../utils/formatters';
import { INITIAL_TRANSACTIONS, INITIAL_DEBTS } from '../data/defaultData';
import { Download, Upload, RefreshCw, Smartphone, ShieldCheck, Database, Trash2, Check, AlertCircle, Copy } from 'lucide-react';

interface BackupRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  debts: DebtRecord[];
  warungId: string;
  warungName: string;
  lastSyncedAt?: number;
  onUpdateWarungId: (newId: string) => void;
  onRestoreData: (restoredTransactions: Transaction[], restoredDebts: DebtRecord[]) => void;
  onManualSync: () => Promise<void>;
}

export const BackupRestoreModal: React.FC<BackupRestoreModalProps> = ({
  isOpen,
  onClose,
  transactions,
  debts,
  warungId,
  warungName,
  lastSyncedAt,
  onUpdateWarungId,
  onRestoreData,
  onManualSync,
}) => {
  const [inputWarungId, setInputWarungId] = useState(warungId);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(warungId);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handleSyncClick = async () => {
    setIsSyncing(true);
    setSyncMessage('');
    try {
      await onManualSync();
      setSyncMessage('Berhasil tersinkronisasi dengan server cloud!');
    } catch {
      setSyncMessage('Gagal sinkronisasi. Pastikan terhubung internet.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleApplyWarungId = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputWarungId.trim()) {
      onUpdateWarungId(inputWarungId.trim().toLowerCase());
      setSyncMessage(`Kode warung diubah menjadi "${inputWarungId.trim().toLowerCase()}". Mengambil data...`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.transactions && Array.isArray(parsed.transactions)) {
          onRestoreData(parsed.transactions, parsed.debts || []);
          alert(`Berhasil memulihkan ${parsed.transactions.length} transaksi dan ${parsed.debts?.length || 0} catatan utang/piutang.`);
          onClose();
        } else {
          alert('Format file JSON tidak valid.');
        }
      } catch {
        alert('Gagal membaca file cadangan. Pastikan file dalam format JSON yang benar.');
      }
    };
    reader.readAsText(file);
  };

  const handleLoadDemo = () => {
    if (window.confirm('Muat kembali data proposal contoh 2026 (Januari - September 2026)?')) {
      onRestoreData(INITIAL_TRANSACTIONS, INITIAL_DEBTS);
      alert('Data proposal contoh berhasil dimuat.');
    }
  };

  const handleClearAll = () => {
    if (window.confirm('PERINGATAN: Yakin ingin menghapus seluruh data catatan keuangan? Tindakan ini tidak dapat dibatalkan.')) {
      onRestoreData([], []);
      alert('Semua data berhasil dibersihkan.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xl max-h-[90vh] rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="px-5 py-4 border-b border-stone-200 bg-[#1E3A2F] text-amber-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-amber-300" />
            <div>
              <h3 className="font-bold text-white text-base">Penyimpanan & Cadangan Data</h3>
              <p className="text-[11px] text-emerald-200">
                Akses dari browser mana saja (Chrome, Edge, Safari, Android & iOS)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-800/40"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs sm:text-sm">
          {/* Section 1: Sinkronisasi Lintas Browser / Perangkat */}
          <div className="p-4 bg-amber-50/60 rounded-xl border border-amber-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                <Smartphone className="w-4 h-4 text-amber-800" />
                <span>Buka Data di HP atau Browser Lain</span>
              </div>
              <span className="text-[11px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-medium">
                Cloud Sync Aktif
              </span>
            </div>

            <p className="text-xs text-stone-600">
              Gunakan <strong>Kode Warung</strong> ini jika Anda ingin membuka catatan yang sama persis di Google Chrome laptop, Chrome HP Android, maupun Safari iPhone.
            </p>

            <div className="flex items-center gap-2">
              <div className="flex-1 bg-white border border-stone-300 px-3 py-2 rounded-lg font-mono font-bold text-stone-800 text-sm flex items-center justify-between">
                <span>{warungId}</span>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="text-xs text-emerald-800 hover:text-emerald-950 font-sans flex items-center gap-1 cursor-pointer"
                >
                  {copySuccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copySuccess ? 'Tersalin' : 'Salin'}</span>
                </button>
              </div>

              <button
                type="button"
                onClick={handleSyncClick}
                disabled={isSyncing}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan'}</span>
              </button>
            </div>

            {/* Custom Warung ID form */}
            <form onSubmit={handleApplyWarungId} className="pt-2 border-t border-amber-200/60 flex items-center gap-2">
              <span className="text-[11px] text-stone-500 whitespace-nowrap">Ganti Kode Warung:</span>
              <input
                type="text"
                placeholder="Contoh: warung-jaya-01"
                value={inputWarungId}
                onChange={(e) => setInputWarungId(e.target.value)}
                className="flex-1 px-2.5 py-1 bg-white border border-stone-300 rounded text-xs text-stone-800"
              />
              <button
                type="submit"
                className="px-2.5 py-1 bg-stone-800 text-white text-xs rounded hover:bg-stone-900 cursor-pointer"
              >
                Terapkan
              </button>
            </form>

            {syncMessage && (
              <div className="text-[11px] text-emerald-800 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>{syncMessage}</span>
              </div>
            )}
          </div>

          {/* Section 2: Unduh Cadangan Data (Backup) */}
          <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-3">
            <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Cadangan Data Keuangan</span>
            </div>
            <p className="text-xs text-stone-600">
              Simpan file cadangan secara berkala agar pembukuan kas warung tetap aman walaupun perangkat di-reset atau ganti HP.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => exportBackupJSON(transactions, debts)}
                className="p-3 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-left transition-colors cursor-pointer"
              >
                <span className="font-semibold text-stone-900 text-xs block">
                  📄 Unduh Cadangan Lengkap (.JSON)
                </span>
                <span className="text-[11px] text-stone-500 block mt-0.5">
                  Menyimpan {transactions.length} transaksi kas & {debts.length} catatan utang
                </span>
              </button>

              <button
                type="button"
                onClick={() => exportToCSV(transactions, `Rekap-Kas-${warungName}.csv`)}
                className="p-3 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-left transition-colors cursor-pointer"
              >
                <span className="font-semibold text-stone-900 text-xs block">
                  📊 Unduh Rekap Excel (.CSV)
                </span>
                <span className="text-[11px] text-stone-500 block mt-0.5">
                  Bisa dibuka di Microsoft Excel atau Google Sheets
                </span>
              </button>
            </div>
          </div>

          {/* Section 3: Pulihkan Cadangan (Restore) */}
          <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-3">
            <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
              <Upload className="w-4 h-4 text-amber-700" />
              <span>Pulihkan Data dari File Cadangan (Restore)</span>
            </div>
            <p className="text-xs text-stone-600">
              Pilih file `.json` cadangan yang sebelumnya pernah Anda unduh untuk mengembalikan data warung Anda.
            </p>
            <label className="block">
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="block w-full text-xs text-stone-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-50 file:text-emerald-800 hover:file:bg-emerald-100 cursor-pointer"
              />
            </label>
          </div>

          {/* Section 4: Reset ke Nol */}
          <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="text-xs font-semibold text-stone-800 block">Mulai Bersih dari Nol:</span>
              <span className="text-[11px] text-stone-500">Kosongkan seluruh transaksi & saldo kas kembali ke Rp 0</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleClearAll}
                className="px-3 py-1.5 bg-red-50 border border-red-200 hover:bg-red-100 text-red-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Reset Semua ke Nol (0)
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-stone-200 bg-stone-50 flex items-center justify-between text-xs text-stone-500">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Tersimpan otomatis di browser ini (LocalStorage)
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 text-white rounded-lg font-semibold hover:bg-stone-900 cursor-pointer"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
