import React, { useState } from 'react';
import { Transaction } from '../types';
import { formatRupiah, formatTanggalIndo } from '../utils/formatters';
import { ArrowDownRight, ArrowUpRight, Edit2, Trash2, Printer, Store, Lock, ArrowLeft, X } from 'lucide-react';
import { ConfirmModal } from './ConfirmModal';

interface TransactionListProps {
  transactions: Transaction[];
  warungName: string;
  activeTypeFilter?: 'all' | 'pemasukan' | 'pengeluaran';
  onEdit: (tx: Transaction) => void;
  onDelete: (id: string) => void;
  onClearHistory?: () => void;
  onOpenNewTransaction: (type?: 'pemasukan' | 'pengeluaran') => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  warungName,
  activeTypeFilter = 'all',
  onEdit,
  onDelete,
  onClearHistory,
  onOpenNewTransaction,
}) => {
  const [printTx, setPrintTx] = useState<Transaction | null>(null);
  const [itemToDelete, setItemToDelete] = useState<{ id: string; label: string } | null>(null);
  const [isConfirmClearAllOpen, setIsConfirmClearAllOpen] = useState(false);

  const handleDeleteClick = (tx: Transaction) => {
    const label = tx.type === 'pengeluaran' ? `Belanja di ${tx.category}` : 'Penjualan Harian Warung';
    setItemToDelete({
      id: tx.id,
      label: `${label} sebesar ${formatRupiah(tx.amount)} (${tx.date})`,
    });
  };

  const handleConfirmSingleDelete = () => {
    if (itemToDelete) {
      onDelete(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const handleConfirmClearAll = () => {
    if (onClearHistory) {
      onClearHistory();
    }
    setIsConfirmClearAllOpen(false);
  };

  return (
    <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
      {/* Table / List Header */}
      <div className="px-4 py-3 border-b border-stone-100 flex flex-wrap items-center justify-between gap-2 bg-stone-50/60">
        <div className="flex items-center gap-2">
          <h3 className="font-bold text-stone-800 text-sm tracking-wide uppercase">
            Riwayat Arus Kas
          </h3>
          <span className="text-xs text-stone-500 font-mono">
            ({transactions.length} transaksi)
          </span>
        </div>

        <div className="flex items-center gap-2">
          {transactions.length > 0 && onClearHistory && (
            <button
              type="button"
              onClick={() => setIsConfirmClearAllOpen(true)}
              className="text-xs font-semibold text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Semua Riwayat</span>
            </button>
          )}

          {activeTypeFilter === 'pemasukan' ? (
            <button
              type="button"
              onClick={() => onOpenNewTransaction('pemasukan')}
              className="text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
            >
              <ArrowDownRight className="w-3.5 h-3.5 text-emerald-600" />
              <span>+ Tambah Catatan Kas Masuk</span>
            </button>
          ) : activeTypeFilter === 'pengeluaran' ? (
            <button
              type="button"
              onClick={() => onOpenNewTransaction('pengeluaran')}
              className="text-xs font-bold text-rose-800 hover:text-rose-950 bg-rose-50 hover:bg-rose-100 border border-rose-300 px-3 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
              <span>+ Tambah Catatan Kas Keluar</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onOpenNewTransaction('pemasukan')}
                className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1"
              >
                <ArrowDownRight className="w-3.5 h-3.5 text-emerald-600" />
                <span>+ Kas Masuk</span>
              </button>
              <button
                type="button"
                onClick={() => onOpenNewTransaction('pengeluaran')}
                className="text-xs font-semibold text-rose-800 hover:text-rose-950 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1"
              >
                <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
                <span>+ Kas Keluar</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {transactions.length === 0 ? (
        <div className="py-12 px-4 text-center">
          <div className="w-12 h-12 mx-auto rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-3">
            <Store className="w-6 h-6" />
          </div>
          <h4 className="font-semibold text-stone-700 text-sm">Tidak ada transaksi ditemukan</h4>
          <p className="text-xs text-stone-500 max-w-sm mx-auto mt-1 mb-4">
            {activeTypeFilter === 'pemasukan'
              ? 'Belum ada catatan kas masuk (penjualan) pada filter periode ini.'
              : activeTypeFilter === 'pengeluaran'
              ? 'Belum ada catatan kas keluar (belanja grosir) pada filter periode ini.'
              : 'Tidak ada transaksi pada filter periode ini atau belum ada pencatatan yang dimasukkan.'}
          </p>
          <div className="flex items-center justify-center gap-2">
            {activeTypeFilter === 'pemasukan' ? (
              <button
                type="button"
                onClick={() => onOpenNewTransaction('pemasukan')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-xs"
              >
                <ArrowDownRight className="w-4 h-4" />
                <span>+ Catat Kas Masuk Baru</span>
              </button>
            ) : activeTypeFilter === 'pengeluaran' ? (
              <button
                type="button"
                onClick={() => onOpenNewTransaction('pengeluaran')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-xs"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>+ Catat Kas Keluar Baru</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onOpenNewTransaction('pemasukan')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  <ArrowDownRight className="w-4 h-4" />
                  <span>+ Catat Kas Masuk</span>
                </button>
                <button
                  type="button"
                  onClick={() => onOpenNewTransaction('pengeluaran')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>+ Catat Kas Keluar</span>
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="divide-y divide-stone-100">
          {transactions.map((tx) => {
            const editCount = tx.editCount || 0;
            const remainingChances = Math.max(0, 3 - editCount);
            const isLocked = editCount >= 3;

            return (
              <div
                key={tx.id}
                className="p-3.5 sm:p-4 hover:bg-stone-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                {/* Left Zone: Direction icon & Info */}
                <div className="flex items-start sm:items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 border ${
                      tx.type === 'pemasukan'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-rose-50 text-rose-700 border-rose-200'
                    }`}
                  >
                    {tx.type === 'pemasukan' ? (
                      <ArrowDownRight className="w-5 h-5" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5" />
                    )}
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-stone-900 text-sm">
                        {tx.type === 'pengeluaran' ? `Belanja di ${tx.category}` : 'Penjualan Harian Warung'}
                      </span>
                      <span className="text-[11px] text-stone-400 font-mono">·</span>
                      <span className="text-[11px] text-stone-500 flex items-center gap-1 font-medium">
                        {formatTanggalIndo(tx.date, { short: true })}
                        {tx.time && <span className="font-mono text-[10px] text-stone-400">({tx.time})</span>}
                      </span>

                      {/* Edit chances badge */}
                      {editCount > 0 && (
                        <span
                          className={`text-[10px] font-mono px-1.5 py-0.2 rounded border ${
                            isLocked
                              ? 'bg-rose-50 text-rose-800 border-rose-200'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}
                          title={`Diedit ${editCount}x dari batas 3x. Sisa kesempatan edit: ${remainingChances}`}
                        >
                          {isLocked ? 'Terkunci (3x edit)' : `Edit: ${editCount}/3`}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-stone-500">
                      Nominal: <strong className="font-semibold text-stone-800 font-mono">{formatRupiah(tx.amount)}</strong>
                    </p>
                  </div>
                </div>

                {/* Right Zone: Amount & Actions */}
                <div className="flex items-center justify-between sm:justify-end gap-3 pl-12 sm:pl-0">
                  <div className="text-left sm:text-right">
                    <div
                      className={`text-sm sm:text-base font-bold tabular-nums ${
                        tx.type === 'pemasukan' ? 'text-emerald-700' : 'text-rose-700'
                      }`}
                    >
                      {tx.type === 'pemasukan' ? '+' : '-'} {formatRupiah(tx.amount)}
                    </div>
                    <span className="text-[10px] text-stone-400 uppercase tracking-wider block">
                      {tx.type === 'pemasukan' ? 'Uang Masuk' : 'Uang Keluar'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 opacity-90 sm:opacity-60 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      title="Cetak Struk/Kwitansi"
                      onClick={() => setPrintTx(tx)}
                      className="p-1.5 text-stone-500 hover:text-stone-800 hover:bg-stone-200/70 rounded-md transition-colors cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>

                    {/* Edit Button with 3-times limit */}
                    {isLocked ? (
                      <span
                        title="Batas 3 kali edit telah tercapai. Data tidak dapat diubah lagi."
                        className="p-1.5 text-stone-300 rounded-md cursor-not-allowed"
                      >
                        <Lock className="w-3.5 h-3.5 text-stone-400" />
                      </span>
                    ) : (
                      <button
                        type="button"
                        title={`Edit Transaksi (Sisa kesempatan: ${remainingChances}x)`}
                        onClick={() => onEdit(tx)}
                        className="p-1.5 text-stone-500 hover:text-stone-800 hover:bg-stone-200/70 rounded-md transition-colors cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      type="button"
                      title="Hapus Transaksi Ini"
                      onClick={() => handleDeleteClick(tx)}
                      className="p-1.5 text-stone-500 hover:text-rose-700 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Confirmation Modal for Single Transaction Delete */}
      <ConfirmModal
        isOpen={itemToDelete !== null}
        title="Hapus Transaksi Ini?"
        message={`Apakah Anda yakin ingin menghapus catatan "${itemToDelete?.label}"? Transaksi yang dihapus akan memperbarui saldo kas secara otomatis.`}
        confirmLabel="Ya, Hapus Transaksi"
        cancelLabel="Batal"
        isDanger={true}
        onConfirm={handleConfirmSingleDelete}
        onCancel={() => setItemToDelete(null)}
      />

      {/* Confirmation Modal for Clear All History */}
      <ConfirmModal
        isOpen={isConfirmClearAllOpen}
        title="Hapus Seluruh Riwayat Transaksi?"
        message={`Perhatian: Tindakan ini akan menghapus semua (${transactions.length}) riwayat kas masuk dan belanja dari buku kas Anda dan mengembalikan saldo ke Rp 0. Apakah Anda yakin ingin melanjutkan?`}
        confirmLabel="Ya, Hapus Semua Riwayat"
        cancelLabel="Batal"
        isDanger={true}
        onConfirm={handleConfirmClearAll}
        onCancel={() => setIsConfirmClearAllOpen(false)}
      />

      {/* Receipt Modal with Back/Exit Arrow */}
      {printTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl border border-stone-200 overflow-hidden animate-in fade-in duration-150">
            {/* Header with Exit Arrow */}
            <div className="p-3 bg-stone-100 border-b border-stone-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setPrintTx(null)}
                className="flex items-center gap-1.5 text-xs font-semibold text-stone-700 hover:text-stone-950 px-2 py-1 rounded-lg hover:bg-stone-200 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Keluar</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-2.5 py-1 bg-stone-800 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3 h-3" /> Cetak
                </button>
                <button
                  type="button"
                  onClick={() => setPrintTx(null)}
                  className="text-stone-400 hover:text-stone-700 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Receipt Body */}
            <div className="p-6 font-mono text-xs space-y-3 bg-[#FCFBF8]">
              <div className="text-center pb-2 border-b border-dashed border-stone-300">
                <div className="font-bold text-sm text-stone-900">{warungName}</div>
                <div className="text-[10px] text-stone-500">Pencatatan Keuangan Warung</div>
                <div className="text-[10px] text-stone-400 mt-1">
                  {formatTanggalIndo(printTx.date)} {printTx.time || ''}
                </div>
              </div>

              <div className="space-y-1.5 py-2 border-b border-dashed border-stone-300">
                <div className="flex justify-between">
                  <span className="text-stone-500">Tipe:</span>
                  <span className="font-bold uppercase">
                    {printTx.type === 'pemasukan' ? 'Kas Masuk' : 'Kas Keluar'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">
                    {printTx.type === 'pengeluaran' ? 'Tempat Belanja:' : 'Sumber Kas:'}
                  </span>
                  <span className="font-semibold text-stone-900">
                    {printTx.type === 'pengeluaran' ? `Belanja di ${printTx.category}` : 'Penjualan Harian Warung'}
                  </span>
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center text-sm font-bold border-b border-dashed border-stone-300 pb-3">
                <span>TOTAL:</span>
                <span className={printTx.type === 'pemasukan' ? 'text-emerald-800' : 'text-rose-800'}>
                  {formatRupiah(printTx.amount)}
                </span>
              </div>

              <div className="text-center text-[10px] text-stone-400 pt-1">
                Tercatat rapi di Note Warung
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
