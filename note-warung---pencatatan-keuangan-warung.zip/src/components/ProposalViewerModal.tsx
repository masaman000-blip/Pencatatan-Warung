import React from 'react';
import { X, FileText, CheckCircle, Store, Shield, Calendar, Award, ArrowLeft } from 'lucide-react';
import { BatikBorderAccent } from './Ornaments';

interface ProposalViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProposalViewerModal: React.FC<ProposalViewerModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95">
        {/* Modal Topbar */}
        <div className="px-5 py-4 border-b border-stone-200 bg-[#1E3A2F] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-bold text-sm sm:text-base">Dokumen Proposal Pengajuan Sistem</h3>
              <p className="text-[11px] text-emerald-200">
                Web Pencatatan Keuangan Warung — "Note Warung"
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onClose}
              className="flex items-center gap-1 text-xs font-semibold text-emerald-100 hover:text-white bg-emerald-900/70 hover:bg-emerald-800 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Keluar</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-800/50 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Styled Document Presentation */}
        <div className="p-5 sm:p-6 overflow-y-auto text-stone-800 text-xs sm:text-sm space-y-5 bg-[#FCFBF8]">
          {/* Header Card */}
          <div className="p-4 bg-white rounded-xl border border-amber-200/80 shadow-xs space-y-1">
            <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block">
              Status: Proposal Teknis & Fitur Terverifikasi
            </span>
            <h1 className="text-base sm:text-lg font-bold text-stone-900">
              Web Pencatatan Keuangan Warung — "Note Warung"
            </h1>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-stone-500 text-xs pt-1 border-t border-stone-100">
              <span>📅 Pengajuan: 24 September 2026</span>
              <span>🚀 Target Operasional: Januari 2026</span>
              <span>📑 Halaman: 1 dari 3</span>
            </div>
          </div>

          <BatikBorderAccent />

          {/* Bab 1 */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
              <span className="w-1.5 h-4 bg-emerald-700 rounded-full inline-block" />
              1. Pendahuluan & Latar Belakang
            </h4>
            <p className="text-stone-600 leading-relaxed text-xs sm:text-sm">
              Dalam pengelolaan keuangan usaha mikro seperti warung kelontong atau grosir, pencatatan transaksi yang rapi dan akurat merupakan fondasi penting untuk menjaga keberlangsungan bisnis. Banyak pengelola warung masih menggunakan metode manual berbasis kertas yang rentan terhadap risiko kerusakan, kehilangan data, serta kesulitan dalam merekapitulasi arus kas secara rinci.
            </p>
            <p className="text-stone-600 leading-relaxed text-xs sm:text-sm">
              Aplikasi web <strong>"Note Warung"</strong> hadir sebagai solusi digital yang praktis, intuitif, dan responsif untuk membantu pemilik warung mencatat setiap pemasukan dan pengeluaran secara terstruktur, memantau pengeluaran berdasarkan pemasok (vendor), serta melihat analisis finansial secara berkala.
            </p>
          </div>

          {/* Bab 2 */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
              <span className="w-1.5 h-4 bg-emerald-700 rounded-full inline-block" />
              2. Tujuan Pengembangan
            </h4>
            <ul className="list-disc list-inside text-stone-600 text-xs sm:text-sm space-y-1 pl-1">
              <li>Mempermudah pembukuan harian arus kas (pemasukan dan pengeluaran).</li>
              <li>Menyediakan kategorisasi pengeluaran spesifik untuk toko/grosir langganan warung.</li>
              <li>Menyajikan rekapitulasi data pengeluaran otomatis per minggu dan per bulan.</li>
              <li>Memberikan analisis performa bisnis melalui pencatatan rekor pemasukan dan pengeluaran tertinggi.</li>
              <li>Menyediakan fleksibilitas filter tanggal historis yang terorganisir mulai dari Januari 2026 hingga masa mendatang.</li>
            </ul>
          </div>

          {/* Bab 3 */}
          <div className="space-y-2">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
              <span className="w-1.5 h-4 bg-emerald-700 rounded-full inline-block" />
              3. Rincian Fitur Utama & Kebutuhan Sistem
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-white rounded-lg border border-stone-200">
                <span className="font-bold text-emerald-800 block mb-1">1. Pencatatan Pemasukan</span>
                <p className="text-stone-600 text-[11px]">
                  Pencatatan hasil penjualan atau pendapatan harian warung lengkap dengan jam dan deskripsi.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-stone-200">
                <span className="font-bold text-rose-800 block mb-1">2. Pilihan Toko / Grosir</span>
                <p className="text-stone-600 text-[11px]">
                  Terintegrasi: Toko Plastik, Grosir 36, Grosir Ruwais, Grosir mg aep, dan Operasional Warung.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-stone-200">
                <span className="font-bold text-amber-800 block mb-1">3. Rekapitulasi Mingguan & Bulanan</span>
                <p className="text-stone-600 text-[11px]">
                  Laporan otomatis rentang 7 hari terakhir dan 1 bulan penuh per kategori toko belanja.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-stone-200">
                <span className="font-bold text-blue-800 block mb-1">4. Selector Tanggal Interaktif</span>
                <p className="text-stone-600 text-[11px]">
                  Penyaringan data surut mulai dari Januari 2026 sampai periode mendatang tanpa batasan.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-stone-200 sm:col-span-2">
                <span className="font-bold text-purple-800 block mb-1">5. Analisis Puncak Keuangan</span>
                <p className="text-stone-600 text-[11px]">
                  Deteksi cerdas rekor pemasukan terbesar dan rekor pengeluaran tertinggi warung.
                </p>
              </div>
            </div>
          </div>

          {/* Bab 4 & 5 */}
          <div className="p-3.5 bg-amber-50/50 rounded-xl border border-amber-200 text-xs space-y-1.5">
            <h5 className="font-bold text-amber-950">Fitur Pelengkap Bebas Error:</h5>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-stone-700">
              <div>✅ Validasi Form Anti-Error</div>
              <div>✅ Fitur Backup & Restore Data</div>
              <div>✅ Dashboard Ringkasan Kas</div>
              <div>✅ Fitur Pencarian & Filter Cepat</div>
              <div>✅ Desain Responsif (Mobile-Friendly)</div>
              <div>✅ Buku Utang & Piutang Kasbon</div>
            </div>
          </div>

          {/* Tanda Tangan */}
          <div className="pt-4 border-t border-stone-200 flex justify-between text-xs text-stone-500">
            <div>
              <span className="block font-medium">Disiapkan Oleh:</span>
              <span className="font-bold text-stone-800 mt-1 block">Tim Pengembang "Note Warung"</span>
            </div>
            <div className="text-right">
              <span className="block font-medium">Disetujui Oleh:</span>
              <span className="font-bold text-stone-800 mt-1 block">Pengelola / Pemilik Warung</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-stone-200 bg-stone-50 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 text-white rounded-lg text-xs font-semibold hover:bg-stone-900 cursor-pointer"
          >
            Tutup Dokumen
          </button>
        </div>
      </div>
    </div>
  );
};
