import React, { useState } from 'react';
import { DebtRecord, DebtType, DebtStatus, PRESET_VENDORS } from '../types';
import { formatRupiah, formatTanggalIndo, parseRupiahInput, getTodayDateString } from '../utils/formatters';
import { Plus, User, Store, Phone, Calendar, Clock, CheckCircle2, MessageCircle, DollarSign, Trash2, ChevronRight, AlertCircle, X, Edit2, Lock, ArrowLeft } from 'lucide-react';
import { BatikBorderAccent } from './Ornaments';
import { ConfirmModal } from './ConfirmModal';

interface DebtCreditSectionProps {
  debts: DebtRecord[];
  warungName: string;
  onSaveDebt: (debt: DebtRecord) => void;
  onDeleteDebt: (id: string) => void;
  onRecordPayment: (debtId: string, paymentAmount: number, paymentNote: string) => void;
}

export const DebtCreditSection: React.FC<DebtCreditSectionProps> = ({
  debts,
  warungName,
  onSaveDebt,
  onDeleteDebt,
  onRecordPayment,
}) => {
  const [typeFilter, setTypeFilter] = useState<'all' | DebtType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | DebtStatus>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [activePaymentDebt, setActivePaymentDebt] = useState<DebtRecord | null>(null);
  const [payAmountRaw, setPayAmountRaw] = useState('');
  const [payNote, setPayNote] = useState('');
  const [debtToDelete, setDebtToDelete] = useState<{ id: string; name: string } | null>(null);

  // Editing Debt state
  const [editingDebt, setEditingDebt] = useState<DebtRecord | null>(null);
  const [editPersonName, setEditPersonName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editTotalRaw, setEditTotalRaw] = useState('');
  const [editDueDate, setEditDueDate] = useState('');
  const [editItemsNote, setEditItemsNote] = useState('');
  const [editError, setEditError] = useState('');

  // Form states for adding new record
  const [newType, setNewType] = useState<DebtType>('piutang');
  const [personName, setPersonName] = useState('');
  const [phone, setPhone] = useState('');
  const [amountRaw, setAmountRaw] = useState('');
  const [debtDate, setDebtDate] = useState(getTodayDateString());
  const [dueDate, setDueDate] = useState('');
  const [itemsNote, setItemsNote] = useState('');
  const [formError, setFormError] = useState('');

  // Calculations
  const activeReceivables = debts
    .filter((d) => d.type === 'piutang' && d.status !== 'lunas')
    .reduce((sum, d) => sum + (d.totalAmount - d.paidAmount), 0);

  const activePayables = debts
    .filter((d) => d.type === 'utang' && d.status !== 'lunas')
    .reduce((sum, d) => sum + (d.totalAmount - d.paidAmount), 0);

  const completedCount = debts.filter((d) => d.status === 'lunas').length;

  // Filtered list
  const filteredDebts = debts.filter((d) => {
    if (typeFilter !== 'all' && d.type !== typeFilter) return false;
    if (statusFilter !== 'all' && d.status !== statusFilter) return false;
    return true;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const totalAmount = parseRupiahInput(amountRaw);
    if (!personName.trim()) {
      setFormError('Nama pelanggan atau nama grosir wajib diisi.');
      return;
    }
    if (totalAmount <= 0) {
      setFormError('Nominal utang/piutang harus lebih besar dari Rp 0.');
      return;
    }

    const newRecord: DebtRecord = {
      id: `debt-${Date.now()}`,
      type: newType,
      personName: personName.trim(),
      phone: phone.trim() || undefined,
      totalAmount,
      paidAmount: 0,
      date: debtDate || getTodayDateString(),
      dueDate: dueDate || undefined,
      itemsNote: itemsNote.trim() || 'Kasbon warung',
      status: 'belum_lunas',
      payments: [],
      createdAt: Date.now(),
    };

    onSaveDebt(newRecord);
    setIsAddModalOpen(false);
    // Reset form
    setPersonName('');
    setPhone('');
    setAmountRaw('');
    setDueDate('');
    setItemsNote('');
    setFormError('');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePaymentDebt) return;
    const payAmt = parseRupiahInput(payAmountRaw);
    const remaining = activePaymentDebt.totalAmount - activePaymentDebt.paidAmount;

    if (payAmt <= 0) return;
    if (payAmt > remaining) {
      alert(`Nominal pembayaran melebihi sisa utang (${formatRupiah(remaining)}).`);
      return;
    }

    onRecordPayment(activePaymentDebt.id, payAmt, payNote.trim() || 'Cicilan pembayaran');
    setActivePaymentDebt(null);
    setPayAmountRaw('');
    setPayNote('');
  };

  const openWhatsAppReminder = (debt: DebtRecord) => {
    const remaining = debt.totalAmount - debt.paidAmount;
    let cleanPhone = (debt.phone || '').replace(/\D/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '62' + cleanPhone.slice(1);
    }
    const message = encodeURIComponent(
      `Halo Kak ${debt.personName}, sekadar informasi dan pengingat catatan kasbon di ${warungName}:\n` +
      `• Total: ${formatRupiah(debt.totalAmount)}\n` +
      `• Sudah dibayar: ${formatRupiah(debt.paidAmount)}\n` +
      `• Sisa yang belum: ${formatRupiah(remaining)}\n` +
      (debt.dueDate ? `• Janji bayar: ${formatTanggalIndo(debt.dueDate)}\n` : '') +
      `• Rincian: ${debt.itemsNote}\n\nTerima kasih banyak ya Kak 🙏`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Top Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Card 1: Piutang Pelanggan (Uang di Luar) */}
        <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Piutang Pelanggan (Kasbon)
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-amber-900 tabular-nums">
            {formatRupiah(activeReceivables)}
          </div>
          <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2 flex justify-between">
            <span>Uang warung di pelanggan</span>
            <span className="font-semibold text-amber-800">
              {debts.filter((d) => d.type === 'piutang' && d.status !== 'lunas').length} Orang
            </span>
          </div>
        </div>

        {/* Card 2: Utang ke Grosir (Kewajiban) */}
        <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Utang Warung (Tempo Grosir)
            </span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center">
              <Store className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-rose-800 tabular-nums">
            {formatRupiah(activePayables)}
          </div>
          <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2 flex justify-between">
            <span>Kewajiban bayar ke supplier</span>
            <span className="font-semibold text-rose-800">
              {debts.filter((d) => d.type === 'utang' && d.status !== 'lunas').length} Grosir
            </span>
          </div>
        </div>

        {/* Card 3: Riwayat Lunas */}
        <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Catatan Lunas
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-800 tabular-nums">
            {completedCount} Selesai
          </div>
          <div className="mt-2 text-[11px] text-stone-500 border-t border-stone-100 pt-2">
            Riwayat kasbon & tempo yang tuntas
          </div>
        </div>
      </div>

      {/* Filter & Action Bar */}
      <div className="bg-white rounded-xl border border-stone-200/80 p-3.5 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Type selector tabs */}
        <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg overflow-x-auto text-xs">
          <button
            type="button"
            onClick={() => setTypeFilter('all')}
            className={`px-3 py-1.5 font-medium rounded-md whitespace-nowrap transition-colors ${
              typeFilter === 'all' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Semua ({debts.length})
          </button>
          <button
            type="button"
            onClick={() => setTypeFilter('piutang')}
            className={`px-3 py-1.5 font-medium rounded-md whitespace-nowrap transition-colors ${
              typeFilter === 'piutang' ? 'bg-amber-600 text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Piutang Pelanggan ({debts.filter((d) => d.type === 'piutang').length})
          </button>
          <button
            type="button"
            onClick={() => setTypeFilter('utang')}
            className={`px-3 py-1.5 font-medium rounded-md whitespace-nowrap transition-colors ${
              typeFilter === 'utang' ? 'bg-rose-600 text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Utang Grosir ({debts.filter((d) => d.type === 'utang').length})
          </button>
        </div>

        {/* Status Dropdown & Add Button */}
        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 font-medium text-stone-700 cursor-pointer"
          >
            <option value="all">Semua Status</option>
            <option value="belum_lunas">Belum Lunas</option>
            <option value="cicilan">Cicilan Sebagian</option>
            <option value="lunas">Lunas</option>
          </select>

          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Catat Kasbon / Utang</span>
          </button>
        </div>
      </div>

      {/* Debts & Credits List */}
      <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
        {filteredDebts.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <div className="w-12 h-12 mx-auto rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-2">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="font-semibold text-stone-700 text-sm">Tidak ada catatan utang/piutang</h4>
            <p className="text-xs text-stone-500 max-w-sm mx-auto mt-1 mb-4">
              Bagus! Tidak ada tunggakan kasbon atau utang pada filter yang dipilih.
            </p>
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs"
            >
              + Catat Kasbon Baru
            </button>
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {filteredDebts.map((item) => {
              const remaining = item.totalAmount - item.paidAmount;
              const isPaid = item.status === 'lunas' || remaining <= 0;
              const progressPct = Math.min(100, Math.round((item.paidAmount / item.totalAmount) * 100));

              return (
                <div key={item.id} className="p-4 hover:bg-stone-50/70 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* Left: Info */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                            item.type === 'piutang'
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : 'bg-rose-100 text-rose-900 border border-rose-300'
                          }`}
                        >
                          {item.type === 'piutang' ? 'Kasbon Pelanggan' : 'Utang ke Grosir'}
                        </span>

                        <span className="font-bold text-stone-900 text-sm">
                          {item.personName}
                        </span>

                        {/* Status badge */}
                        <span
                          className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                            isPaid
                              ? 'bg-emerald-100 text-emerald-800'
                              : item.paidAmount > 0
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-stone-100 text-stone-700'
                          }`}
                        >
                          {isPaid ? 'Lunas' : item.paidAmount > 0 ? `Dicicil (${progressPct}%)` : 'Belum Dibayar'}
                        </span>
                      </div>

                      <p className="text-xs text-stone-600">
                        {item.itemsNote || 'Tanpa rincian'}
                      </p>

                      <div className="flex items-center gap-3 text-[11px] text-stone-500 pt-0.5">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-stone-400" />
                          {formatTanggalIndo(item.date, { short: true })}
                        </span>
                        {item.dueDate && (
                          <span className="flex items-center gap-1 text-amber-800 font-medium">
                            <Clock className="w-3 h-3" />
                            Janji: {formatTanggalIndo(item.dueDate, { short: true })}
                          </span>
                        )}
                        {item.phone && (
                          <span className="flex items-center gap-1 text-stone-500 font-mono">
                            <Phone className="w-3 h-3 text-stone-400" />
                            {item.phone}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Right: Numbers & Actions */}
                    <div className="flex flex-col sm:items-end gap-2">
                      <div className="flex items-baseline gap-2">
                        <span className="text-xs text-stone-500">Sisa:</span>
                        <span className={`text-base font-bold tabular-nums ${isPaid ? 'text-emerald-700' : 'text-stone-900'}`}>
                          {formatRupiah(remaining)}
                        </span>
                      </div>
                      <div className="text-[11px] text-stone-500">
                        Total: {formatRupiah(item.totalAmount)}
                        {item.paidAmount > 0 && ` (Sudah bayar: ${formatRupiah(item.paidAmount)})`}
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 pt-1">
                        {!isPaid && (
                          <button
                            type="button"
                            onClick={() => {
                              setActivePaymentDebt(item);
                              setPayAmountRaw(String(remaining));
                            }}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                          >
                            <DollarSign className="w-3 h-3" />
                            <span>Catat Bayar</span>
                          </button>
                        )}

                        {item.phone && !isPaid && item.type === 'piutang' && (
                          <button
                            type="button"
                            onClick={() => openWhatsAppReminder(item)}
                            title="Kirim pengingat kasbon via WhatsApp"
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-md text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <MessageCircle className="w-3 h-3 text-emerald-600" />
                            <span>WhatsApp</span>
                          </button>
                        )}

                        {/* Edit Debt Button with 3-times limit */}
                        {(item.editCount || 0) >= 3 ? (
                          <span
                            title="Batas 3 kali edit telah tercapai. Catatan tidak dapat diubah lagi."
                            className="p-1 text-stone-300 rounded cursor-not-allowed"
                          >
                            <Lock className="w-3.5 h-3.5 text-stone-400" />
                          </span>
                        ) : (
                          <button
                            type="button"
                            title={`Edit Catatan Kasbon/Utang (Sisa kesempatan: ${3 - (item.editCount || 0)}x)`}
                            onClick={() => {
                              setEditingDebt(item);
                              setEditPersonName(item.personName);
                              setEditPhone(item.phone || '');
                              setEditTotalRaw(String(item.totalAmount));
                              setEditDueDate(item.dueDate || '');
                              setEditItemsNote(item.itemsNote);
                              setEditError('');
                            }}
                            className="p-1 text-stone-400 hover:text-stone-700 hover:bg-stone-200/70 rounded transition-colors cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          title="Hapus Catatan"
                          onClick={() => setDebtToDelete({ id: item.id, name: item.personName })}
                          className="p-1 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Payment History timeline if any payments exist */}
                  {item.payments && item.payments.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-stone-100 text-xs">
                      <div className="text-[11px] font-semibold text-stone-500 mb-1">
                        Riwayat Cicilan Pembayaran:
                      </div>
                      <div className="space-y-1">
                        {item.payments.map((p) => (
                          <div key={p.id} className="flex items-center justify-between bg-stone-50/90 px-2.5 py-1 rounded text-[11px]">
                            <span className="text-stone-600">
                              {formatTanggalIndo(p.date, { short: true })} · {p.note || 'Bayar cicilan'}
                            </span>
                            <span className="font-bold text-emerald-700 font-mono">
                              +{formatRupiah(p.amount)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal: Tambah Kasbon / Utang Baru */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">Catat Utang / Piutang Baru</h3>
                  <p className="text-[11px] text-stone-500">Buku kasbon pelanggan & tempo belanja grosir</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-5 space-y-4">
              {formError && (
                <div className="p-2.5 bg-red-50 text-red-700 text-xs rounded-lg flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Type Switcher */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5 uppercase tracking-wider">
                  Jenis Pencatatan
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setNewType('piutang');
                      setPersonName('');
                    }}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                      newType === 'piutang'
                        ? 'bg-amber-50 border-amber-600 text-amber-900 ring-2 ring-amber-600/20'
                        : 'border-stone-200 text-stone-600'
                    }`}
                  >
                    Piutang (Kasbon Pelanggan)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewType('utang');
                      setPersonName('Grosir 36');
                    }}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                      newType === 'utang'
                        ? 'bg-rose-50 border-rose-600 text-rose-900 ring-2 ring-rose-600/20'
                        : 'border-stone-200 text-stone-600'
                    }`}
                  >
                    Utang ke Grosir (Tempo)
                  </button>
                </div>
              </div>

              {/* Name and Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                    {newType === 'piutang' ? 'Nama Pelanggan' : 'Nama Grosir/Supplier'}
                  </label>
                  {newType === 'utang' ? (
                    <select
                      value={personName}
                      onChange={(e) => setPersonName(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs sm:text-sm font-medium"
                    >
                      {PRESET_VENDORS.map((v) => (
                        <option key={v} value={v}>
                          {v}
                        </option>
                      ))}
                      <option value="Grosir Lain">Grosir Lain</option>
                    </select>
                  ) : (
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Pak Joko (RT 03)"
                      value={personName}
                      onChange={(e) => setPersonName(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs sm:text-sm"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                    No. WhatsApp (Opsional)
                  </label>
                  <input
                    type="tel"
                    placeholder="Contoh: 081234567890"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs sm:text-sm font-mono"
                  />
                </div>
              </div>

              {/* Nominal */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Total Nominal (Rp)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  placeholder="0"
                  value={amountRaw ? Number(amountRaw).toLocaleString('id-ID') : ''}
                  onChange={(e) => setAmountRaw(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-sm font-bold tabular-nums"
                />
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                    Tanggal Kasbon
                  </label>
                  <input
                    type="date"
                    required
                    value={debtDate}
                    onChange={(e) => setDebtDate(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                    Janji Bayar (Jatuh Tempo)
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Rincian Barang Belanjaan
                </label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Beras 5kg, Minyak 1L, Telur 1/2 kg, Rokok 1 bungkus"
                  value={itemsNote}
                  onChange={(e) => setItemsNote(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-stone-600 hover:text-stone-900 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-xs cursor-pointer"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Catat Cicilan Pembayaran */}
      {activePaymentDebt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl border border-stone-200 p-5 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <h3 className="font-bold text-stone-900 text-sm">
                Catat Pembayaran Cicilan
              </h3>
              <button
                type="button"
                onClick={() => setActivePaymentDebt(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-stone-50 p-3 rounded-lg text-xs space-y-1">
              <div className="font-semibold text-stone-800">{activePaymentDebt.personName}</div>
              <div className="text-stone-500">
                Sisa utang saat ini:{' '}
                <span className="font-bold text-amber-800 font-mono">
                  {formatRupiah(activePaymentDebt.totalAmount - activePaymentDebt.paidAmount)}
                </span>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Nominal Dibayar (Rp)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  autoFocus
                  placeholder="0"
                  value={payAmountRaw ? Number(payAmountRaw).toLocaleString('id-ID') : ''}
                  onChange={(e) => setPayAmountRaw(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg font-bold text-sm tabular-nums"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Catatan Pembayaran
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Titip uang belanja sore"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActivePaymentDebt(null)}
                  className="px-3 py-1.5 text-xs text-stone-600 hover:text-stone-900"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Konfirmasi Bayar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Catatan Utang / Piutang (Maksimal 3x Edit) */}
      {editingDebt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl border border-stone-200 p-5 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <div>
                <h3 className="font-bold text-stone-900 text-sm">
                  Koreksi Data Utang / Kasbon
                </h3>
                <p className="text-[11px] text-stone-500">
                  Perbaiki data jika terjadi kesalahan input
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingDebt(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 3-times edit alert banner */}
            <div className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
              (editingDebt.editCount || 0) >= 3
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : 3 - (editingDebt.editCount || 0) === 1
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}>
              <div className="flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>
                  Sisa kesempatan edit:{' '}
                  <strong>{Math.max(0, 3 - (editingDebt.editCount || 0))} kali lagi</strong>
                </span>
              </div>
              <span className="font-mono font-bold text-[10px] px-1.5 py-0.5 bg-white rounded border border-current">
                {editingDebt.editCount || 0}/3
              </span>
            </div>

            {editError && (
              <div className="p-2 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{editError}</span>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const curEdits = editingDebt.editCount || 0;
                if (curEdits >= 3) {
                  setEditError('Batas 3 kali edit telah tercapai. Data tidak dapat diubah.');
                  return;
                }
                const newTotal = parseRupiahInput(editTotalRaw);
                if (newTotal <= 0) {
                  setEditError('Nominal utang harus lebih besar dari Rp 0.');
                  return;
                }
                if (newTotal < editingDebt.paidAmount) {
                  setEditError(`Nominal tidak boleh lebih kecil dari yang sudah dibayar (${formatRupiah(editingDebt.paidAmount)}).`);
                  return;
                }

                const updatedDebtRecord: DebtRecord = {
                  ...editingDebt,
                  personName: editPersonName.trim() || editingDebt.personName,
                  phone: editPhone.trim() || undefined,
                  totalAmount: newTotal,
                  dueDate: editDueDate || undefined,
                  itemsNote: editItemsNote.trim() || editingDebt.itemsNote,
                  editCount: curEdits + 1,
                  status: (newTotal <= editingDebt.paidAmount ? 'lunas' : editingDebt.paidAmount > 0 ? 'cicilan' : 'belum_lunas') as any,
                };

                onSaveDebt(updatedDebtRecord);
                setEditingDebt(null);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Nama Pelanggan / Toko
                </label>
                <input
                  type="text"
                  required
                  value={editPersonName}
                  onChange={(e) => setEditPersonName(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs sm:text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Nominal Total (Rp)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  value={editTotalRaw ? Number(editTotalRaw).toLocaleString('id-ID') : ''}
                  onChange={(e) => setEditTotalRaw(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg font-bold text-sm tabular-nums"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                    No. WhatsApp
                  </label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                    Janji Bayar
                  </label>
                  <input
                    type="date"
                    value={editDueDate}
                    onChange={(e) => setEditDueDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1 uppercase tracking-wider">
                  Rincian Barang
                </label>
                <textarea
                  rows={2}
                  value={editItemsNote}
                  onChange={(e) => setEditItemsNote(e.target.value)}
                  className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setEditingDebt(null)}
                  className="px-3 py-1.5 text-xs text-stone-600 hover:text-stone-900 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-semibold rounded-lg text-xs shadow-xs cursor-pointer"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Delete Debt Modal */}
      <ConfirmModal
        isOpen={debtToDelete !== null}
        title="Hapus Catatan Utang / Piutang?"
        message={`Apakah Anda yakin ingin menghapus catatan atas nama "${debtToDelete?.name}"? Tindakan ini tidak dapat dibatalkan.`}
        confirmLabel="Ya, Hapus Catatan"
        cancelLabel="Batal"
        isDanger={true}
        onConfirm={() => {
          if (debtToDelete) {
            onDeleteDebt(debtToDelete.id);
            setDebtToDelete(null);
          }
        }}
        onCancel={() => setDebtToDelete(null)}
      />
    </div>
  );
};
