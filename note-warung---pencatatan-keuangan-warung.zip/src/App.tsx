/**
 * Note Warung — Sistem Pencatatan Keuangan Warung
 * Halaman-halaman Terpisah: Ringkasan Kas, Buku Kas, Utang Piutang, Laporan Rekapan (1 Hari, 1 Minggu, 1 Bulan), Cadangan & Cookies
 */

import React, { useState, useEffect, useMemo } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Navbar, AppPage } from './components/Navbar';
import { DashboardPage } from './components/DashboardPage';
import { DateFilterBar, FilterState } from './components/DateFilterBar';
import { TransactionList } from './components/TransactionList';
import { TransactionModal } from './components/TransactionModal';
import { DebtCreditSection } from './components/DebtCreditSection';
import { DetailedRecapPage } from './components/DetailedRecapPage';
import { StorageCookiesPage } from './components/StorageCookiesPage';
import { ProposalViewerModal } from './components/ProposalViewerModal';
import { EditWarungNameModal } from './components/EditWarungNameModal';
import { BatikBorderAccent } from './components/Ornaments';
import { Transaction, DebtRecord, TransactionType } from './types';
import {
  loadLocalData,
  saveLocalData,
  getActiveWarungId,
  setActiveWarungId,
  getSavedWarungName,
  setSavedWarungName,
  getSavedActiveTab,
  setSavedActiveTab,
  syncWithServer,
  fetchFromServer,
  areCookiesEnabled,
} from './utils/storage';
import { getTodayDateString } from './utils/formatters';
import { FileText, Cookie, ShieldCheck, Database, PlusCircle, BookOpen, Clock, BarChart3, ArrowLeft } from 'lucide-react';

export default function App() {
  // Storage & Profile States
  const [warungId, setWarungId] = useState<string>(getActiveWarungId());
  const [warungName, setWarungName] = useState<string>(getSavedWarungName());
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [debts, setDebts] = useState<DebtRecord[]>([]);
  const [lastSyncedAt, setLastSyncedAt] = useState<number | undefined>(undefined);

  // Navigation State (Terpisah per halaman, tersimpan di cookies)
  const [activeTab, setActiveTabState] = useState<AppPage>(() => {
    const saved = getSavedActiveTab();
    if (['dashboard', 'buku_kas', 'utang_piutang', 'rekapitulasi', 'cadangan'].includes(saved)) {
      return saved as AppPage;
    }
    return 'dashboard';
  });

  const setActiveTab = (tab: AppPage) => {
    setActiveTabState(tab);
    setSavedActiveTab(tab);
  };

  // Modals
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [modalDefaultType, setModalDefaultType] = useState<TransactionType>('pemasukan');
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [isEditNameOpen, setIsEditNameOpen] = useState(false);
  const [isProposalOpen, setIsProposalOpen] = useState(false);

  const handleOpenNewTransaction = (specificType?: TransactionType) => {
    const chosenType: TransactionType =
      specificType ||
      (filters.typeFilter === 'pemasukan'
        ? 'pemasukan'
        : filters.typeFilter === 'pengeluaran'
        ? 'pengeluaran'
        : modalDefaultType);
    setModalDefaultType(chosenType);
    setEditingTx(null);
    setIsTxModalOpen(true);
  };

  // Filters untuk Halaman Buku Kas (Januari 2026 - Seterusnya)
  const [filters, setFilters] = useState<FilterState>({
    periodType: 'all',
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    searchQuery: '',
    categoryFilter: 'all',
    typeFilter: 'all',
  });

  // Load initial data from local storage & cookies & server
  useEffect(() => {
    const local = loadLocalData();
    setTransactions(local.transactions);
    setDebts(local.debts);

    (async () => {
      try {
        const serverResult = await fetchFromServer(warungId);
        if (serverResult.success && serverResult.data) {
          if (serverResult.data.transactions) {
            setTransactions(serverResult.data.transactions);
            setDebts(serverResult.data.debts || []);
            saveLocalData(serverResult.data.transactions, serverResult.data.debts || []);
          }
          if (serverResult.data.warungName) {
            setWarungName(serverResult.data.warungName);
            setSavedWarungName(serverResult.data.warungName);
          }
        }
      } catch (e) {
        console.warn('Initial server sync using local fallback.');
      }
    })();
  }, [warungId]);

  // Persist helper
  const updateAndPersist = (newTransactions: Transaction[], newDebts: DebtRecord[]) => {
    setTransactions(newTransactions);
    setDebts(newDebts);
    saveLocalData(newTransactions, newDebts);
    // Background cloud sync
    syncWithServer(warungId, newTransactions, newDebts, warungName).then((res) => {
      if (res.success && res.updatedAt) {
        setLastSyncedAt(res.updatedAt);
      }
    });
  };

  // Transaction Handlers
  const handleSaveTransaction = (tx: Transaction) => {
    const exists = transactions.some((t) => t.id === tx.id);
    let updated: Transaction[];
    if (exists) {
      updated = transactions.map((t) => (t.id === tx.id ? tx : t));
    } else {
      updated = [tx, ...transactions];
    }
    // Urutkan tanggal terbaru di atas
    updated.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    updateAndPersist(updated, debts);
    setEditingTx(null);
  };

  const handleDeleteTransaction = (id: string) => {
    const updated = transactions.filter((t) => t.id !== id);
    updateAndPersist(updated, debts);
  };

  const handleClearTransactionsHistory = () => {
    updateAndPersist([], debts);
  };

  // Debt Handlers
  const handleSaveDebt = (debt: DebtRecord) => {
    const exists = debts.some((d) => d.id === debt.id);
    let updated: DebtRecord[];
    if (exists) {
      updated = debts.map((d) => (d.id === debt.id ? debt : d));
    } else {
      updated = [debt, ...debts];
    }
    updateAndPersist(transactions, updated);
  };

  const handleDeleteDebt = (id: string) => {
    const updated = debts.filter((d) => d.id !== id);
    updateAndPersist(transactions, updated);
  };

  const handleRecordPayment = (debtId: string, paymentAmount: number, paymentNote: string) => {
    const targetDebt = debts.find((d) => d.id === debtId);
    if (!targetDebt) return;

    const newPaidAmount = targetDebt.paidAmount + paymentAmount;
    const isNowLunas = newPaidAmount >= targetDebt.totalAmount;

    const newPaymentRecord = {
      id: `pay-${Date.now()}`,
      amount: paymentAmount,
      date: getTodayDateString(),
      note: paymentNote,
    };

    const updatedDebts = debts.map((d) => {
      if (d.id !== debtId) return d;
      return {
        ...d,
        paidAmount: newPaidAmount,
        status: (isNowLunas ? 'lunas' : 'cicilan') as any,
        payments: [newPaymentRecord, ...(d.payments || [])],
      };
    });

    // Otomatis catat di kas masuk / keluar
    let updatedTransactions = [...transactions];
    if (targetDebt.type === 'piutang') {
      const cashInTx: Transaction = {
        id: `tx-pay-${Date.now()}`,
        type: 'pemasukan',
        amount: paymentAmount,
        date: getTodayDateString(),
        time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        category: 'Penjualan Harian Warung',
        note: `Terima bayar kasbon dari ${targetDebt.personName} (${paymentNote})`,
        createdAt: Date.now(),
      };
      updatedTransactions = [cashInTx, ...updatedTransactions];
    } else {
      const cashOutTx: Transaction = {
        id: `tx-pay-${Date.now()}`,
        type: 'pengeluaran',
        amount: paymentAmount,
        date: getTodayDateString(),
        time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        category: targetDebt.personName.includes('Grosir') ? targetDebt.personName : 'Lainnya / Operasional Warung',
        note: `Bayar utang tempo ke ${targetDebt.personName} (${paymentNote})`,
        createdAt: Date.now(),
      };
      updatedTransactions = [cashOutTx, ...updatedTransactions];
    }

    updateAndPersist(updatedTransactions, updatedDebts);
  };

  const handleSaveWarungName = (newName: string) => {
    setWarungName(newName);
    setSavedWarungName(newName);
    syncWithServer(warungId, transactions, debts, newName);
  };

  const handleUpdateWarungId = async (newId: string) => {
    setActiveWarungId(newId);
    setWarungId(newId);
    try {
      const res = await fetchFromServer(newId);
      if (res.success && res.data) {
        setTransactions(res.data.transactions || []);
        setDebts(res.data.debts || []);
        if (res.data.warungName) {
          setWarungName(res.data.warungName);
          setSavedWarungName(res.data.warungName);
        }
        saveLocalData(res.data.transactions || [], res.data.debts || []);
      }
    } catch (err) {
      console.warn('Update warung id error:', err);
    }
  };

  const handleManualSync = async () => {
    const res = await syncWithServer(warungId, transactions, debts, warungName);
    if (res.success && res.updatedAt) {
      setLastSyncedAt(res.updatedAt);
    }
  };

  // Filtered Transactions untuk Halaman Buku Kas
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (filters.typeFilter !== 'all' && tx.type !== filters.typeFilter) return false;
      if (filters.categoryFilter !== 'all' && tx.category !== filters.categoryFilter) return false;

      const txDate = tx.date;
      if (filters.periodType === 'today') {
        if (txDate !== '2026-09-24' && txDate !== getTodayDateString()) return false;
      } else if (filters.periodType === 'week') {
        const anchor = new Date('2026-09-24T23:59:59');
        const weekAgo = new Date(anchor.getTime() - 7 * 24 * 60 * 60 * 1000);
        const cur = new Date(txDate);
        if (cur < weekAgo || cur > anchor) return false;
      } else if (filters.periodType === 'month') {
        if (!txDate.startsWith('2026-09')) return false;
      } else if (filters.periodType.startsWith('2026-')) {
        if (!txDate.startsWith(filters.periodType)) return false;
      } else if (filters.periodType === 'custom') {
        if (filters.startDate && txDate < filters.startDate) return false;
        if (filters.endDate && txDate > filters.endDate) return false;
      }

      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase();
        const matchesCategory = tx.category.toLowerCase().includes(q);
        const matchesNote = (tx.note || '').toLowerCase().includes(q);
        const matchesAmount = String(tx.amount).includes(q);
        const matchesDate = tx.date.includes(q);
        if (!matchesCategory && !matchesNote && !matchesAmount && !matchesDate) return false;
      }

      return true;
    });
  }, [transactions, filters]);

  const unpaidDebtCount = debts.filter((d) => d.status !== 'lunas').length;

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-stone-800 selection:bg-amber-100">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unpaidDebtCount={unpaidDebtCount}
        warungName={warungName}
        onOpenEditWarungName={() => setIsEditNameOpen(true)}
        onOpenProposalViewer={() => setIsProposalOpen(true)}
      />

      {/* Indonesian motif ornament strip */}
      <BatikBorderAccent className="bg-[#1E3A2F]" />

      {/* Main Container: Halaman-halaman Terpisah dengan Animasi Halus */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-5">
        {/* Tombol Tanda Panah Keluar dari Fitur (Menuju Ringkasan Utama) */}
        {activeTab !== 'dashboard' && (
          <div className="mb-4">
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-stone-100 text-stone-800 border border-stone-200 shadow-2xs text-xs sm:text-sm font-bold transition-all cursor-pointer group"
            >
              <ArrowLeft className="w-4 h-4 text-emerald-800 group-hover:-translate-x-1 transition-transform" />
              <span>Keluar ke Ringkasan Utama</span>
            </button>
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 14, filter: 'blur(2px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -10, filter: 'blur(1px)' }}
            transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
          >
            {/* ======================================================== */}
            {/* HALAMAN 1: DASHBOARD / RINGKASAN KAS                     */}
            {/* ======================================================== */}
            {activeTab === 'dashboard' && (
              <DashboardPage
                transactions={transactions}
                debts={debts}
                warungName={warungName}
                onNavigateTab={(tab, type) => {
                  setActiveTab(tab);
                  if (type) {
                    setFilters((prev) => ({ ...prev, typeFilter: type }));
                    setModalDefaultType(type);
                  }
                }}
              />
            )}

            {/* ======================================================== */}
            {/* HALAMAN 2: BUKU KAS (TRANSAKSI)                          */}
            {/* ======================================================== */}
            {activeTab === 'buku_kas' && (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-emerald-800" />
                      <h2 className="text-base font-bold text-stone-900">Buku Kas & Riwayat Transaksi</h2>
                    </div>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Catat pemasukan dan pengeluaran belanja stok. Filter per tanggal mulai Januari 2026 - seterusnya.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setActiveTab('dashboard')}
                      className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Keluar</span>
                    </button>
                    {filters.typeFilter === 'pemasukan' ? (
                      <button
                        type="button"
                        onClick={() => handleOpenNewTransaction('pemasukan')}
                        className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                      >
                        <PlusCircle className="w-4 h-4" />
                        <span>+ Catat Kas Masuk</span>
                      </button>
                    ) : filters.typeFilter === 'pengeluaran' ? (
                      <button
                        type="button"
                        onClick={() => handleOpenNewTransaction('pengeluaran')}
                        className="px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                      >
                        <PlusCircle className="w-4 h-4" />
                        <span>+ Catat Kas Keluar</span>
                      </button>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenNewTransaction('pemasukan')}
                          className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>+ Catat Kas Masuk</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenNewTransaction('pengeluaran')}
                          className="px-3 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>+ Catat Kas Keluar</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Filter Bar with Date Selector */}
                <DateFilterBar
                  filters={filters}
                  onFilterChange={(newFilters) => {
                    setFilters(newFilters);
                    if (newFilters.typeFilter === 'pemasukan') setModalDefaultType('pemasukan');
                    if (newFilters.typeFilter === 'pengeluaran') setModalDefaultType('pengeluaran');
                  }}
                  onResetFilters={() =>
                    setFilters({
                      periodType: 'all',
                      startDate: '2026-01-01',
                      endDate: '2026-12-31',
                      searchQuery: '',
                      categoryFilter: 'all',
                      typeFilter: 'all',
                    })
                  }
                />

                {/* Transactions List with functional Clear History */}
                <TransactionList
                  transactions={filteredTransactions}
                  warungName={warungName}
                  activeTypeFilter={filters.typeFilter}
                  onEdit={(tx) => {
                    setEditingTx(tx);
                    setIsTxModalOpen(true);
                  }}
                  onDelete={handleDeleteTransaction}
                  onClearHistory={handleClearTransactionsHistory}
                  onOpenNewTransaction={(type) => handleOpenNewTransaction(type)}
                />
              </div>
            )}

            {/* ======================================================== */}
            {/* HALAMAN 3: BUKU UTANG & PIUTANG                          */}
            {/* ======================================================== */}
            {activeTab === 'utang_piutang' && (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-800" />
                      <h2 className="text-base font-bold text-stone-900">Buku Utang & Piutang (Kasbon Warung)</h2>
                    </div>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Kelola kasbon belanja pelanggan warung dan utang tempo belanja ke grosir. Dilengkapi fitur cicilan & pengingat WhatsApp.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('dashboard')}
                    className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Keluar</span>
                  </button>
                </div>

                <DebtCreditSection
                  debts={debts}
                  warungName={warungName}
                  onSaveDebt={handleSaveDebt}
                  onDeleteDebt={handleDeleteDebt}
                  onRecordPayment={handleRecordPayment}
                />
              </div>
            )}

            {/* ======================================================== */}
            {/* HALAMAN 4: LAPORAN REKAPAN (1 HARI, 1 MINGGU, 1 BULAN)   */}
            {/* ======================================================== */}
            {activeTab === 'rekapitulasi' && (
              <DetailedRecapPage
                transactions={transactions}
                warungName={warungName}
                onExit={() => setActiveTab('dashboard')}
              />
            )}

            {/* ======================================================== */}
            {/* HALAMAN 5: CADANGAN & COOKIES                            */}
            {/* ======================================================== */}
            {activeTab === 'cadangan' && (
              <StorageCookiesPage
                transactions={transactions}
                debts={debts}
                warungId={warungId}
                warungName={warungName}
                lastSyncedAt={lastSyncedAt}
                onUpdateWarungId={handleUpdateWarungId}
                onRestoreData={(t, d) => updateAndPersist(t, d)}
                onManualSync={handleManualSync}
                onExit={() => setActiveTab('dashboard')}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-stone-200/80 bg-white py-4 text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-800">{warungName}</span>
            <span className="text-stone-300">·</span>
            <span>Target Operasional: Mulai Januari 2026</span>
            <span className="text-stone-300">·</span>
            <span className="text-emerald-700 flex items-center gap-1 font-medium">
              <Cookie className="w-3.5 h-3.5" /> Cookies Aktif
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px]">
            <button
              type="button"
              onClick={() => setIsProposalOpen(true)}
              className="text-stone-600 hover:text-emerald-800 cursor-pointer"
            >
              Lihat Dokumen Proposal
            </button>
            <span>·</span>
            <button
              type="button"
              onClick={() => setActiveTab('cadangan')}
              className="text-stone-600 hover:text-emerald-800 cursor-pointer"
            >
              Pengaturan Cookies & Backup
            </button>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => {
          setIsTxModalOpen(false);
          setEditingTx(null);
        }}
        onSave={handleSaveTransaction}
        editingTransaction={editingTx}
        defaultType={modalDefaultType}
      />

      <EditWarungNameModal
        isOpen={isEditNameOpen}
        currentName={warungName}
        onClose={() => setIsEditNameOpen(false)}
        onSave={handleSaveWarungName}
      />

      <ProposalViewerModal
        isOpen={isProposalOpen}
        onClose={() => setIsProposalOpen(false)}
      />
    </div>
  );
}
