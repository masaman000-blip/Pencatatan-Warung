/**
 * Utility functions for formatting Indonesian Rupiah, dates, and handling data backup
 */

export function formatRupiah(amount: number): string {
  if (isNaN(amount)) return 'Rp 0';
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function parseRupiahInput(value: string): number {
  // strip all non-digits
  const clean = value.replace(/\D/g, '');
  if (!clean) return 0;
  const num = parseInt(clean, 10);
  return isNaN(num) ? 0 : Math.max(0, num);
}

export function formatTanggalIndo(dateStr: string, options?: { short?: boolean; withDay?: boolean }): string {
  if (!dateStr) return '-';
  try {
    const [year, month, day] = dateStr.split('-').map(Number);
    if (!year || !month || !day) return dateStr;
    const date = new Date(year, month - 1, day);
    
    if (options?.withDay) {
      return date.toLocaleDateString('id-ID', {
        weekday: 'long',
        day: 'numeric',
        month: options?.short ? 'short' : 'long',
        year: 'numeric',
      });
    }

    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: options?.short ? 'short' : 'long',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentTimeString(): string {
  const d = new Date();
  const hours = String(d.getHours()).padStart(2, '0');
  const mins = String(d.getMinutes()).padStart(2, '0');
  return `${hours}:${mins}`;
}

/**
 * Export data to CSV file formatted for Excel
 */
export function exportToCSV(transactions: any[], filename = 'Laporan-Note-Warung.csv') {
  const headers = ['ID', 'Tipe', 'Tanggal', 'Jam', 'Kategori/Toko', 'Nominal (Rp)', 'Keterangan'];
  const rows = transactions.map((t) => [
    t.id,
    t.type === 'pemasukan' ? 'Pemasukan (Uang Masuk)' : 'Pengeluaran (Uang Keluar)',
    t.date,
    t.time || '',
    `"${(t.category || '').replace(/"/g, '""')}"`,
    t.amount,
    `"${(t.note || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(';'), ...rows.map((e) => e.join(';'))].join('\r\n');
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Export all data (transactions & debts) to JSON backup file
 */
export function exportBackupJSON(transactions: any[], debts: any[]) {
  const backupData = {
    appName: 'Note Warung',
    version: '1.0.0',
    exportDate: new Date().toISOString(),
    transactions,
    debts,
  };
  const jsonStr = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Backup-Note-Warung-${getTodayDateString()}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
