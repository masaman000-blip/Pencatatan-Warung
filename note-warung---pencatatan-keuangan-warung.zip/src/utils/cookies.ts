/**
 * Sistem Penyimpanan Cookies Browser untuk Note Warung
 * Menyimpan preferensi, identitas warung, dan sinkronisasi data antar halaman browser
 */

export function setCookie(name: string, value: string, days: number = 365): void {
  try {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    const expires = '; expires=' + date.toUTCString();
    // Use encodeURIComponent to safely store text, numbers, and Indonesian names
    document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}${expires}; path=/; SameSite=Lax`;
  } catch (err) {
    console.warn('Gagal menyimpan cookie:', err);
  }
}

export function getCookie(name: string): string | null {
  try {
    const nameEQ = encodeURIComponent(name) + '=';
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) {
        return decodeURIComponent(c.substring(nameEQ.length, c.length));
      }
    }
  } catch (err) {
    console.warn('Gagal membaca cookie:', err);
  }
  return null;
}

export function deleteCookie(name: string): void {
  try {
    document.cookie = `${encodeURIComponent(name)}=; Max-Age=-99999999; path=/; SameSite=Lax`;
  } catch (err) {
    console.warn('Gagal menghapus cookie:', err);
  }
}

export function areCookiesEnabled(): boolean {
  try {
    setCookie('__test_cookie__', '1', 1);
    const enabled = getCookie('__test_cookie__') === '1';
    deleteCookie('__test_cookie__');
    return enabled;
  } catch {
    return false;
  }
}
