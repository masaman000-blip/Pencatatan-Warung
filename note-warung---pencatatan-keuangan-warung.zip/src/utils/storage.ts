import { Transaction, DebtRecord } from '../types';
import { INITIAL_TRANSACTIONS, INITIAL_DEBTS } from '../data/defaultData';
import { setCookie, getCookie, areCookiesEnabled } from './cookies';

const STORAGE_KEY_TX = 'note_warung_tx_fresh_v2';
const STORAGE_KEY_DEBT = 'note_warung_debt_fresh_v2';
const STORAGE_KEY_WARUNG_ID = 'note_warung_active_id';
const STORAGE_KEY_WARUNG_NAME = 'note_warung_store_name';
const COOKIE_WARUNG_ID = 'nw_warung_id';
const COOKIE_WARUNG_NAME = 'nw_warung_name';
const COOKIE_ACTIVE_TAB = 'nw_active_tab';

export interface StorageData {
  transactions: Transaction[];
  debts: DebtRecord[];
  warungId: string;
  warungName: string;
  lastSyncedAt?: number;
}

export function getActiveWarungId(): string {
  try {
    const savedId = localStorage.getItem(STORAGE_KEY_WARUNG_ID);
    if (savedId) return savedId;
    // Fallback to cookie
    const cookieId = getCookie(COOKIE_WARUNG_ID);
    if (cookieId) return cookieId;
  } catch {
    // fallback
  }
  return 'warung-utama';
}

export function setActiveWarungId(id: string) {
  const cleanId = id.trim().toLowerCase();
  try {
    localStorage.setItem(STORAGE_KEY_WARUNG_ID, cleanId);
    setCookie(COOKIE_WARUNG_ID, cleanId, 365);
  } catch {
    // fallback
  }
}

export function getSavedWarungName(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_WARUNG_NAME);
    if (saved) return saved;
    // Fallback to cookie
    const cookieName = getCookie(COOKIE_WARUNG_NAME);
    if (cookieName) return cookieName;
  } catch {
    // fallback
  }
  return 'Note Warung Kelontong';
}

export function setSavedWarungName(name: string) {
  try {
    localStorage.setItem(STORAGE_KEY_WARUNG_NAME, name);
    setCookie(COOKIE_WARUNG_NAME, name, 365);
  } catch {
    // fallback
  }
}

export function getSavedActiveTab(): string {
  try {
    const tab = getCookie(COOKIE_ACTIVE_TAB);
    if (tab) return tab;
  } catch {
    // fallback
  }
  return 'dashboard';
}

export function setSavedActiveTab(tab: string) {
  try {
    setCookie(COOKIE_ACTIVE_TAB, tab, 30);
  } catch {
    // fallback
  }
}

/**
 * Load initial data from localStorage or default seed
 */
export function loadLocalData(): { transactions: Transaction[]; debts: DebtRecord[] } {
  try {
    const txRaw = localStorage.getItem(STORAGE_KEY_TX);
    const debtRaw = localStorage.getItem(STORAGE_KEY_DEBT);

    const transactions: Transaction[] = txRaw ? JSON.parse(txRaw) : INITIAL_TRANSACTIONS;
    const debts: DebtRecord[] = debtRaw ? JSON.parse(debtRaw) : INITIAL_DEBTS;

    return { transactions, debts };
  } catch (e) {
    console.error('Error loading local storage data:', e);
    return { transactions: INITIAL_TRANSACTIONS, debts: INITIAL_DEBTS };
  }
}

/**
 * Save data to local storage instantly & record snapshot timestamp in cookie
 */
export function saveLocalData(transactions: Transaction[], debts: DebtRecord[]) {
  try {
    localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(transactions));
    localStorage.setItem(STORAGE_KEY_DEBT, JSON.stringify(debts));
    setCookie('nw_last_save_time', new Date().toISOString(), 30);
    setCookie('nw_tx_count', String(transactions.length), 30);
    setCookie('nw_debt_count', String(debts.length), 30);
  } catch (e) {
    console.error('Error saving local storage:', e);
  }
}

/**
 * Synchronize with backend server API so data is accessible across any browser / device
 */
export async function syncWithServer(
  warungId: string,
  transactions: Transaction[],
  debts: DebtRecord[],
  warungName: string
): Promise<{ success: boolean; updatedAt?: number }> {
  try {
    const res = await fetch(`/api/warung/${encodeURIComponent(warungId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transactions, debts, warungName }),
    });
    if (res.ok) {
      const data = await res.json();
      return { success: true, updatedAt: data.updatedAt };
    }
  } catch (err) {
    console.warn('Server sync warning (offline fallback active):', err);
  }
  return { success: false };
}

/**
 * Fetch data from server API for a specific Warung ID
 */
export async function fetchFromServer(warungId: string): Promise<{
  success: boolean;
  data: { transactions: Transaction[]; debts: DebtRecord[]; warungName?: string } | null;
}> {
  try {
    const res = await fetch(`/api/warung/${encodeURIComponent(warungId)}`);
    if (res.ok) {
      const json = await res.json();
      if (json.success && json.data) {
        return { success: true, data: json.data };
      }
    }
  } catch (err) {
    console.warn('Error fetching from server, using local data:', err);
  }
  return { success: false, data: null };
}

export { areCookiesEnabled };
