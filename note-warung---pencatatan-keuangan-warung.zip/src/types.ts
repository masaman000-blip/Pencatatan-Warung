export type TransactionType = 'pemasukan' | 'pengeluaran';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  category: string; // e.g., 'Toko Plastik', 'Grosir 36', 'Grosir Ruwais', 'Grosir mg aep', 'Lainnya / Operasional Warung' for expense; or 'Penjualan Warung', etc.
  note: string;
  editCount?: number; // Maksimal 3 kali edit
  createdAt: number;
}

export type DebtType = 'piutang' | 'utang';
// 'piutang' = Uang warung di luar (Kasbon Pelanggan)
// 'utang' = Warung berutang ke Toko/Grosir Supplier

export type DebtStatus = 'belum_lunas' | 'cicilan' | 'lunas';

export interface PaymentRecord {
  id: string;
  amount: number;
  date: string;
  note?: string;
}

export interface DebtRecord {
  id: string;
  type: DebtType;
  personName: string; // Nama Pelanggan atau Nama Toko Grosir
  phone?: string;
  totalAmount: number;
  paidAmount: number;
  date: string; // YYYY-MM-DD
  dueDate?: string; // YYYY-MM-DD
  itemsNote: string; // Rincian belanja/barang
  status: DebtStatus;
  payments: PaymentRecord[];
  editCount?: number; // Maksimal 3 kali edit
  createdAt: number;
}

export const PRESET_VENDORS = [
  'Toko Plastik',
  'Grosir 36',
  'Grosir Ruwais',
  'Grosir mg aep',
  'Lainnya / Operasional Warung',
] as const;

export const PRESET_INCOME_CATEGORIES = [
  'Penjualan Harian Warung',
] as const;
