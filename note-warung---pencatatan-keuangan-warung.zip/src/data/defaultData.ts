import { Transaction, DebtRecord } from '../types';

// Bersih & Kosong: Mulai dari Rp 0 seperti aplikasi baru belum digunakan
export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_DEBTS: DebtRecord[] = [];
