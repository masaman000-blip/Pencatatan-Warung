import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 3000;

// Data persistence directory & file
const DATA_DIR = path.resolve(__dirname, 'server_data');
const DATA_FILE = path.join(DATA_DIR, 'warung_db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface ServerStore {
  warungs: Record<string, {
    transactions: any[];
    debts: any[];
    updatedAt: number;
    warungName?: string;
  }>;
}

function readData(): ServerStore {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Error reading warung database:', err);
  }
  return { warungs: {} };
}

function writeData(data: ServerStore) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing warung database:', err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // API Endpoints for persistent cross-browser data access
  app.get('/api/warung/:id', (req, res) => {
    const warungId = req.params.id || 'default';
    const store = readData();
    const warungData = store.warungs[warungId] || null;
    res.json({ success: true, data: warungData });
  });

  app.post('/api/warung/:id', (req, res) => {
    const warungId = req.params.id || 'default';
    const { transactions, debts, warungName } = req.body;
    const store = readData();
    store.warungs[warungId] = {
      transactions: transactions || [],
      debts: debts || [],
      updatedAt: Date.now(),
      warungName: warungName || 'Note Warung',
    };
    writeData(store);
    res.json({ success: true, message: 'Data berhasil disimpan secara persisten', updatedAt: store.warungs[warungId].updatedAt });
  });

  // Health / status endpoint
  app.get('/api/status', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Note Warung Cloud Persistence API',
      timestamp: new Date().toISOString(),
    });
  });

  if (!isProduction) {
    // Vite middleware for development
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static assets
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[Note Warung] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
